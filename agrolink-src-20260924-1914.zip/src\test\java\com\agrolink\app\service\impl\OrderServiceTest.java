package com.agrolink.app.service.impl;

import com.agrolink.app.dto.AcceptOfferRecord;
import com.agrolink.app.dto.OrderResponseRecord;
import com.agrolink.app.exception.BusinessRuleException;
import com.agrolink.app.model.ListingStatus;
import com.agrolink.app.model.Offer;
import com.agrolink.app.model.OfferStatus;
import com.agrolink.app.model.Order;
import com.agrolink.app.model.OrderStatus;
import com.agrolink.app.model.ProduceListing;
import com.agrolink.app.repository.OfferRepository;
import com.agrolink.app.repository.OrderRepository;
import com.agrolink.app.repository.ProduceListingRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;
    @Mock
    private OfferRepository offerRepository;
    @Mock
    private ProduceListingRepository produceListingRepository;
    @Mock
    private MongoTemplate mongoTemplate;

    private OrderServiceImpl orderService;

    @BeforeEach
    void setUp() {
        orderService = new OrderServiceImpl(orderRepository, offerRepository, produceListingRepository, mongoTemplate);
    }

    @Test
    void acceptOffer_shouldReserveStockSnapshotAndComputeTotalAmount() {
        Offer offer = offer("offer-1", "buyer-1", "farmer-1", "listing-1",
                new BigDecimal("100"), new BigDecimal("10.00"), OfferStatus.OFFERED);
        ProduceListing listing = listing("listing-1", "Wheat");
        when(offerRepository.findById("offer-1")).thenReturn(Optional.of(offer));
        when(produceListingRepository.findById("listing-1")).thenReturn(Optional.of(listing));
        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class), eq(ProduceListing.class)))
                .thenReturn(listing);
        when(offerRepository.save(any(Offer.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(offerRepository.findByListingIdAndStatus("listing-1", OfferStatus.OFFERED)).thenReturn(List.of());
        when(orderRepository.save(any(Order.class))).thenAnswer(invocation -> invocation.getArgument(0));

        OrderResponseRecord result = orderService.acceptOffer("buyer-1",
                new AcceptOfferRecord("offer-1", "Warehouse, Delhi"));

        assertEquals("buyer-1", result.buyerId());
        assertEquals("farmer-1", result.farmerId());
        assertEquals("Wheat", result.cropName());
        assertEquals(new BigDecimal("1000.00"), result.totalAmount());
        assertEquals(OrderStatus.PENDING, result.orderStatus());
        verify(offerRepository).save(offer);
        assertEquals(OfferStatus.ACCEPTED, offer.getStatus());
    }

    @Test
    void acceptOffer_shouldRejectCompetingOffers() {
        Offer offer = offer("offer-1", "buyer-1", "farmer-1", "listing-1",
                new BigDecimal("100"), new BigDecimal("10.00"), OfferStatus.OFFERED);
        Offer competitor = offer("offer-2", "buyer-2", "farmer-1", "listing-1",
                new BigDecimal("80"), new BigDecimal("9.00"), OfferStatus.OFFERED);
        ProduceListing listing = listing("listing-1", "Wheat");
        when(offerRepository.findById("offer-1")).thenReturn(Optional.of(offer));
        when(produceListingRepository.findById("listing-1")).thenReturn(Optional.of(listing));
        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class), eq(ProduceListing.class)))
                .thenReturn(listing);
        when(offerRepository.findByListingIdAndStatus("listing-1", OfferStatus.OFFERED))
                .thenReturn(List.of(offer, competitor));
        when(orderRepository.save(any(Order.class))).thenAnswer(invocation -> invocation.getArgument(0));

        orderService.acceptOffer("buyer-1", new AcceptOfferRecord("offer-1", "Warehouse, Delhi"));

        assertEquals(OfferStatus.REJECTED, competitor.getStatus());
    }

    @Test
    void acceptOffer_shouldRejectOfferPlacedByAnotherBuyer() {
        Offer offer = offer("offer-1", "other-buyer", "farmer-1", "listing-1",
                new BigDecimal("100"), new BigDecimal("10.00"), OfferStatus.OFFERED);
        when(offerRepository.findById("offer-1")).thenReturn(Optional.of(offer));

        assertThrows(BusinessRuleException.class,
                () -> orderService.acceptOffer("buyer-1", new AcceptOfferRecord("offer-1", "Address")));
        verify(orderRepository, never()).save(any(Order.class));
    }

    @Test
    void acceptOffer_shouldRejectOfferThatIsNoLongerOffered() {
        Offer offer = offer("offer-1", "buyer-1", "farmer-1", "listing-1",
                new BigDecimal("100"), new BigDecimal("10.00"), OfferStatus.ACCEPTED);
        when(offerRepository.findById("offer-1")).thenReturn(Optional.of(offer));

        assertThrows(BusinessRuleException.class,
                () -> orderService.acceptOffer("buyer-1", new AcceptOfferRecord("offer-1", "Address")));
        verify(orderRepository, never()).save(any(Order.class));
    }

    @Test
    void acceptOffer_shouldFailWhenAtomicReservationReturnsNull() {
        Offer offer = offer("offer-1", "buyer-1", "farmer-1", "listing-1",
                new BigDecimal("5000"), new BigDecimal("10.00"), OfferStatus.OFFERED);
        ProduceListing listing = listing("listing-1", "Wheat");
        when(offerRepository.findById("offer-1")).thenReturn(Optional.of(offer));
        when(produceListingRepository.findById("listing-1")).thenReturn(Optional.of(listing));
        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class), eq(ProduceListing.class)))
                .thenReturn(null);

        assertThrows(BusinessRuleException.class,
                () -> orderService.acceptOffer("buyer-1", new AcceptOfferRecord("offer-1", "Address")));
        verify(orderRepository, never()).save(any(Order.class));
    }

    @Test
    void getOrderById_shouldForbidUnauthorizedAccess() {
        Order order = order("order-1", "buyer-1", "farmer-1", OrderStatus.PENDING);
        when(orderRepository.findById("order-1")).thenReturn(Optional.of(order));

        assertThrows(BusinessRuleException.class,
                () -> orderService.getOrderById("order-1", "stranger", false));
    }

    @Test
    void getOrderById_shouldAllowAdminAccess() {
        Order order = order("order-1", "buyer-1", "farmer-1", OrderStatus.PENDING);
        when(orderRepository.findById("order-1")).thenReturn(Optional.of(order));

        OrderResponseRecord result = orderService.getOrderById("order-1", "stranger", true);

        assertEquals("order-1", result.id());
    }

    @Test
    void updateOrderStatus_shouldForbidInvalidTransition() {
        Order order = order("order-1", "buyer-1", "farmer-1", OrderStatus.PENDING);
        when(orderRepository.findById("order-1")).thenReturn(Optional.of(order));

        assertThrows(BusinessRuleException.class,
                () -> orderService.updateOrderStatus("order-1", "buyer-1", false, OrderStatus.IN_TRANSIT));
        verify(orderRepository, never()).save(any(Order.class));
    }

    @Test
    void updateOrderStatus_shouldApplyValidTransition() {
        Order order = order("order-1", "buyer-1", "farmer-1", OrderStatus.PENDING);
        when(orderRepository.findById("order-1")).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenAnswer(invocation -> invocation.getArgument(0));

        OrderResponseRecord result =
                orderService.updateOrderStatus("order-1", "buyer-1", false, OrderStatus.CONFIRMED);

        assertEquals(OrderStatus.CONFIRMED, result.orderStatus());
    }

    private Offer offer(String id, String buyerId, String farmerId, String listingId,
                        BigDecimal quantity, BigDecimal price, OfferStatus status) {
        return Offer.builder()
                .id(id)
                .listingId(listingId)
                .farmerId(farmerId)
                .buyerId(buyerId)
                .offeredQuantity(quantity)
                .offeredPrice(price)
                .status(status)
                .build();
    }

    private ProduceListing listing(String id, String cropName) {
        return ProduceListing.builder()
                .id(id)
                .cropName(cropName)
                .category("Grains")
                .availableQuantity(new BigDecimal("5000"))
                .reservedQuantity(BigDecimal.ZERO)
                .unit("kg")
                .pricePerUnit(new BigDecimal("10.00"))
                .location("Punjab")
                .status(ListingStatus.ACTIVE)
                .build();
    }

    private Order order(String id, String buyerId, String farmerId, OrderStatus status) {
        return Order.builder()
                .id(id)
                .buyerId(buyerId)
                .farmerId(farmerId)
                .cropName("Wheat")
                .agreedQuantity(new BigDecimal("100"))
                .agreedPricePerUnit(new BigDecimal("10.00"))
                .totalAmount(new BigDecimal("1000.00"))
                .orderStatus(status)
                .build();
    }
}