package com.agrolink.app.dto;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

/**
 * District forecast payload.
 *
 * @param fallback true when no live AND no previously-saved data exists (daily is empty)
 * @param stale    true when live fetch failed and the last successful forecast is served instead
 */
public record WeatherForecastDTO(
        String district,
        String division,
        BigDecimal latitude,
        BigDecimal longitude,
        int days,
        String units,
        Current current,
        List<DailyForecastDTO> daily,
        Instant generatedAt,
        String provider,
        boolean fallback,
        boolean stale,
        String disclaimer) {

    /** Live "right now" conditions; any field may be null if the provider omitted it. */
    public record Current(
            Double temperatureC,
            Double windKmh,
            Double rainMm,
            Integer weatherCode,
            String description,
            Boolean day,
            String observedAt) {
    }
}