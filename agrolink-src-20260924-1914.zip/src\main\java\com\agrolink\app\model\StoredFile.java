package com.agrolink.app.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

/**
 * An uploaded image stored in MongoDB (works on hosts with an ephemeral disk such as Render).
 * Uploads are capped at 2 MB, far below the 16 MB document limit.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "stored_files")
public class StoredFile {

    @Id
    private String id;

    private String fileName;

    private String contentType;

    private long size;

    /** Email of the uploader (the authentication name). */
    private String uploadedBy;

    @ToString.Exclude
    private byte[] data;

    private Instant createdAt;
}