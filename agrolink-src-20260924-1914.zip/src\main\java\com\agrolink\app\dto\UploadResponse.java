package com.agrolink.app.dto;

/** Result of an image upload. {@code url} is what you store on a listing or profile. */
public record UploadResponse(String id, String url, String contentType, long size) {
}