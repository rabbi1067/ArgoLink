package com.agrolink.app.dto;

import java.time.LocalDate;

/**
 * One forecast day. Numeric fields are {@code null} (never 0) when the provider
 * did not return a value, so the UI can show "--" instead of a fake 0.0.
 */
public record DailyForecastDTO(
        LocalDate date,
        Double tempMaxC,
        Double tempMinC,
        Integer rainProbabilityPct,
        Double rainSumMm,
        Double windMaxKmh,
        Integer weatherCode,
        String description) {
}