package com.agrolink.app.model;

import java.time.LocalDate;

/**
 * Compact, immutable daily forecast row returned by the weather module.
 * All temperatures in °C; rain probability/volume apply to the local 24h window.
 *
 * @param date                local calendar date for the district
 * @param temperatureMaxC     forecast daily max (°C)
 * @param temperatureMinC     forecast daily min (°C)
 * @param precipitationChance daily precipitation probability (0-100)
 * @param precipitationMm     expected 24h precipitation (mm)
 * @param weatherCode         WMO weather-code for the day (see WeatherCodes)
 * @param summary             short human label derived from weatherCode
 */
public record ForecastPoint(
        LocalDate date,
        double temperatureMaxC,
        double temperatureMinC,
        int precipitationChance,
        double precipitationMm,
        int weatherCode,
        String summary) {
}
