package com.agrolink.app.service.impl;

import com.agrolink.app.config.CacheConfig;
import com.agrolink.app.dto.AnalyticsDTO;
import com.agrolink.app.dto.CropDistributionDTO;
import com.agrolink.app.dto.MonthlyVolumeDTO;
import com.agrolink.app.dto.RevenueDTO;
import com.agrolink.app.dto.SupplyDemandDTO;
import com.agrolink.app.model.ListingStatus;
import com.agrolink.app.projection.PriceProjection;
import com.agrolink.app.repository.CategoryRepository;
import com.agrolink.app.repository.OrderRepository;
import com.agrolink.app.repository.ProduceListingRepository;
import com.agrolink.app.repository.UserRepository;
import com.agrolink.app.service.AnalyticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.YearMonth;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

@Service
@RequiredArgsConstructor
public class AnalyticsServiceImpl implements AnalyticsService {

    private final ProduceListingRepository produceListingRepository;
    private final CategoryRepository categoryRepository;
    private final UserRepository userRepository;
    private final OrderRepository orderRepository;
    private final MongoTemplate mongoTemplate;

    @Override
    @Cacheable(cacheNames = CacheConfig.CACHE_DASHBOARD_STATS, key = "'overview'")
    public AnalyticsDTO overview() {
        long activeListings = produceListingRepository.countByStatus(ListingStatus.ACTIVE);
        long totalListings = produceListingRepository.count();
        long totalUsers = userRepository.count();
        long totalCategories = categoryRepository.count();
        long totalOrders = orderRepository.count();

        return AnalyticsDTO.of(
                totalListings,
                activeListings,
                totalUsers,
                totalCategories,
                totalOrders,
                averageActivePricePerUnit()
        );
    }

    @Override
    @Cacheable(cacheNames = CacheConfig.CACHE_DASHBOARD_STATS, key = "'monthly-volume-' + #months")
    public MonthlyVolumeDTO monthlyOrderVolume(int months) {
        List<Map> rows = aggregateMonthly(months, "count");
        return new MonthlyVolumeDTO(
                monthlyBuckets(months),
                rowsToLongSeries(rows, months, row -> toLong(row.get("value")))
        );
    }

    @Override
    @Cacheable(cacheNames = CacheConfig.CACHE_DASHBOARD_STATS, key = "'crop-distribution'")
    public List<CropDistributionDTO> cropDistribution() {
        Aggregation agg = Aggregation.newAggregation(
                Aggregation.group("cropName").count().as("count"),
                Aggregation.sort(Sort.by(Sort.Direction.DESC, "count")),
                Aggregation.limit(12)
        );
        AggregationResults<Map> results = mongoTemplate.aggregate(agg, "orders", Map.class);
        return results.getMappedResults().stream()
                .map(row -> CropDistributionDTO.of(String.valueOf(row.get("_id")), toLong(row.get("count"))))
                .toList();
    }

    @Override
    @Cacheable(cacheNames = CacheConfig.CACHE_DASHBOARD_STATS, key = "'revenue-' + #months")
    public RevenueDTO monthlyRevenue(int months) {
        List<Map> rows = aggregateMonthly(months, "sum");
        return new RevenueDTO(
                monthlyBuckets(months),
                rowsToDecimalSeries(rows, months, row -> toDecimal(row.get("value")))
        );
    }

    @Override
    @Cacheable(cacheNames = CacheConfig.CACHE_DASHBOARD_STATS, key = "'supply-demand'")
    public SupplyDemandDTO supplyDemand() {
        Map<String, BigDecimal> supply = groupedSum(
                "produce_listings",
                Aggregation.match(Criteria.where("status").is(ListingStatus.ACTIVE)),
                "cropName",
                "availableQuantity");
        Map<String, BigDecimal> demand = groupedSum("orders", null, "cropName", "agreedQuantity");

        Set<String> keys = new TreeSet<>(supply.keySet());
        keys.addAll(demand.keySet());

        List<String> labels = new ArrayList<>(keys);
        List<BigDecimal> supplySeries = new ArrayList<>();
        List<BigDecimal> demandSeries = new ArrayList<>();
        for (String key : keys) {
            supplySeries.add(supply.getOrDefault(key, BigDecimal.ZERO));
            demandSeries.add(demand.getOrDefault(key, BigDecimal.ZERO));
        }

        return SupplyDemandDTO.of(labels, supplySeries, demandSeries);
    }

    private Map<String, BigDecimal> groupedSum(String collection, AggregationOperation match, String groupField, String sumField) {
        List<AggregationOperation> operations = new ArrayList<>();
        if (match != null) {
            operations.add(match);
        }
        operations.add(Aggregation.group(groupField).sum(sumField).as("value"));

        AggregationResults<Map> results = mongoTemplate.aggregate(
                Aggregation.newAggregation(operations), collection, Map.class);

        Map<String, BigDecimal> values = new HashMap<>();
        for (Map row : results.getMappedResults()) {
            Object id = row.get("_id");
            if (id != null) {
                values.put(String.valueOf(id), toDecimal(row.get("value")));
            }
        }
        return values;
    }

    private BigDecimal averageActivePricePerUnit() {
        List<PriceProjection> prices = produceListingRepository.findAveragePricePerUnitByStatus(ListingStatus.ACTIVE);
        if (prices.isEmpty() || prices.get(0).pricePerUnit() == null) {
            return BigDecimal.ZERO;
        }
        return prices.get(0).pricePerUnit();
    }

    private List<Map> aggregateMonthly(int months, String mode) {
        Instant cutoff = YearMonth.now().minusMonths(months - 1L).atDay(1)
                .atStartOfDay(ZoneId.systemDefault()).toInstant();
        Aggregation aggregation = buildMonthlyAggregation(cutoff, mode);
        return mongoTemplate.aggregate(aggregation, "orders", Map.class).getMappedResults();
    }

    private Aggregation buildMonthlyAggregation(Instant cutoff, String mode) {
        ProjectionOperation projection =
                Aggregation.project()
                        .andExpression("year(createdAt)").as("year")
                        .andExpression("month(createdAt)").as("month");

        GroupOperation group = "count".equals(mode)
                ? Aggregation.group("year", "month").count().as("value")
                : Aggregation.group("year", "month").sum("totalAmount").as("value");

        ProjectionOperation flatten =
                Aggregation.project()
                        .and("_id.year").as("year")
                        .and("_id.month").as("month")
                        .and("value").as("value");

        return Aggregation.newAggregation(
                Aggregation.match(Criteria.where("createdAt").gte(cutoff)),
                projection,
                group,
                flatten
        );
    }

    private List<Long> rowsToLongSeries(List<Map> rows, int months, java.util.function.Function<Map, Long> extractor) {
        Map<String, Long> byMonth = new HashMap<>();
        for (Map row : rows) {
            byMonth.put(monthKey(row), extractor.apply(row));
        }
        List<Long> data = new ArrayList<>();
        YearMonth start = YearMonth.now().minusMonths(months - 1L);
        for (int i = 0; i < months; i++) {
            data.add(byMonth.getOrDefault(start.plusMonths(i).toString(), 0L));
        }
        return data;
    }

    private List<BigDecimal> rowsToDecimalSeries(List<Map> rows, int months, java.util.function.Function<Map, BigDecimal> extractor) {
        Map<String, BigDecimal> byMonth = new HashMap<>();
        for (Map row : rows) {
            byMonth.put(monthKey(row), extractor.apply(row));
        }
        List<BigDecimal> data = new ArrayList<>();
        YearMonth start = YearMonth.now().minusMonths(months - 1L);
        for (int i = 0; i < months; i++) {
            data.add(byMonth.getOrDefault(start.plusMonths(i).toString(), BigDecimal.ZERO));
        }
        return data;
    }

    private List<String> monthlyBuckets(int months) {
        YearMonth start = YearMonth.now().minusMonths(months - 1L);
        List<String> labels = new ArrayList<>();
        for (int i = 0; i < months; i++) {
            labels.add(start.plusMonths(i).toString());
        }
        return labels;
    }

    private String monthKey(Map row) {
        Number year = toNumber(row.get("year"));
        Number month = toNumber(row.get("month"));
        return String.format("%04d-%02d", year.intValue(), month.intValue());
    }

    private long toLong(Object value) {
        return value instanceof Number number ? number.longValue() : 0L;
    }

    private BigDecimal toDecimal(Object value) {
        return value instanceof Number number
                ? BigDecimal.valueOf(number.doubleValue()).setScale(2, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;
    }

    private Number toNumber(Object value) {
        return value instanceof Number number ? number : 0;
    }
}