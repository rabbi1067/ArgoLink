package com.agrolink.app.service;

import com.agrolink.app.dto.InvoiceDTO;
import com.agrolink.app.model.Order;

import java.util.List;

public interface InvoiceService {

    List<InvoiceDTO> listForUser(String userId);

    InvoiceDTO getById(String invoiceId, String userId, boolean isAdmin);

    InvoiceDTO generateOrGetByOrder(String orderId, String userId, boolean isAdmin);

    void syncForOrder(Order order);
}