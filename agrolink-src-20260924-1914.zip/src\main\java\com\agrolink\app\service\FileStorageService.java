package com.agrolink.app.service;

import com.agrolink.app.dto.UploadResponse;
import com.agrolink.app.model.StoredFile;
import org.springframework.web.multipart.MultipartFile;

public interface FileStorageService {

    /**
     * Validates the image (size + real type by magic bytes) and stores it: on Cloudinary when
     * CLOUDINARY_* environment variables are set, otherwise in MongoDB (local development fallback).
     */
    UploadResponse store(MultipartFile file, String uploadedBy);

    /** Loads an image that was stored in MongoDB (legacy / fallback). Cloudinary images are served by Cloudinary. */
    StoredFile load(String id);
}