window.Pages = window.Pages || {};

window.Pages.orders = {
    container: null,
    role: "BUYER",
    orders: [],
    offers: [],
    listingCache: {},
    isAdmin: false,

    TRANSITIONS: {
        PENDING: ["CONFIRMED", "CANCELLED", "DISPUTED"],
        CONFIRMED: ["IN_TRANSIT", "CANCELLED", "DISPUTED"],
        IN_TRANSIT: ["DELIVERED", "DISPUTED"],
        DELIVERED: ["DISPUTED"],
        CANCELLED: [],
        DISPUTED: [],
    },

    init(container) {
        this.container = container;
        const user = window.Api && Api.getUser ? Api.getUser() : null;
        this.role = user && user.role ? user.role : "BUYER";
        this.isAdmin = this.role === "ADMIN" || this.role === "SUPER_ADMIN";
        this.orders = [];
        this.offers = [];
        this.listingCache = {};

        this.bindControls();
        this.load();
    },

    async load() {
        try {
            await Promise.all([this.loadOrders(), this.loadOffers()]);
        } catch (error) {
            this.renderOrders(this.orders);
            this.renderOffers(this.offers);
            if (window.Toast) Toast.fromResponse(error, "Could not load orders");
        }
    },

    async loadOrders() {
        const filter = this.container.querySelector("#orderStatusFilter");
        const status = filter ? filter.value : "";

        let orders = [];
        if (this.isAdmin) {
            const statuses = status ? [status] : ["PENDING", "CONFIRMED", "IN_TRANSIT"];
            const results = await Promise.all(
                statuses.map((s) => Api.get(`/orders/status/${s}`))
            );
            const seen = new Set();
            results.forEach((res) => {
                (res.data || []).forEach((order) => {
                    if (!seen.has(order.id)) {
                        seen.add(order.id);
                        orders.push(order);
                    }
                });
            });
            orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        } else {
            const as = this.role === "FARMER" ? "FARMER" : "BUYER";
            const res = await Api.get("/orders/my", { as });
            orders = res.data || [];
            if (status) orders = orders.filter((o) => o.orderStatus === status);
        }

        this.orders = orders;
        this.renderOrders(orders);
    },

    async loadOffers() {
        const as = this.role === "FARMER" ? "FARMER" : "BUYER";
        const res = await Api.get("/offers/my", { as });
        this.offers = res.data || [];
        await Promise.all(this.offers.map((offer) => this.ensureListing(offer.listingId)));
        this.renderOffers(this.offers);
    },

    bindControls() {
        const refresh = this.container.querySelector("[data-orders-refresh]");
        if (refresh) refresh.addEventListener("click", () => this.load());

        const filter = this.container.querySelector("#orderStatusFilter");
        if (filter) filter.addEventListener("change", () => this.loadOrders());

        const acceptClose = this.container.querySelector("[data-accept-modal-close]");
        const acceptModal = this.container.querySelector("#acceptModal");
        if (acceptClose) acceptClose.addEventListener("click", () => this.closeModal(acceptModal));

        const counterClose = this.container.querySelector("[data-counter-modal-close]");
        const counterModal = this.container.querySelector("#counterModal");
        if (counterClose) counterClose.addEventListener("click", () => this.closeModal(counterModal));

        this.container.querySelectorAll(".modal-backdrop").forEach((backdrop) => {
            backdrop.addEventListener("click", (event) => {
                if (event.target === backdrop) this.closeModal(backdrop);
            });
        });

        const acceptForm = this.container.querySelector("#acceptForm");
        if (acceptForm) acceptForm.addEventListener("submit", (event) => this.handleAcceptSubmit(event));

        const counterForm = this.container.querySelector("#counterForm");
        if (counterForm) counterForm.addEventListener("submit", (event) => this.handleCounterSubmit(event));

        const offersWrap = this.container.querySelector("#offerList");
        if (offersWrap) offersWrap.addEventListener("click", (event) => this.handleOfferAction(event));

        const ordersWrap = this.container.querySelector("#ordersTableWrap");
        if (ordersWrap) ordersWrap.addEventListener("click", (event) => this.handleOrderAction(event));

        this.state = this.state || {};
        this.state.escHandler = (event) => {
            if (event.key !== "Escape") return;
            const open = this.container.querySelector(".modal-backdrop.open");
            if (open) this.closeModal(open);
        };
        document.addEventListener("keydown", this.state.escHandler);
    },

    handleOrderAction(event) {
        const chat = event.target.closest("[data-order-chat]");
        if (chat) {
            const id = chat.dataset.id;
            Api.post("/messages/conversations", { orderId: id })
                .then((res) => {
                    window.PendingConversation = (res.data && res.data.id) || null;
                    window.location.hash = "messages";
                })
                .catch((error) => {
                    if (window.Toast) Toast.fromResponse(error, "Could not open chat");
                });
            return;
        }

        const button = event.target.closest("[data-order-action]");
        if (!button) return;

        const id = button.dataset.id;
        const status = button.dataset.status;
        if (!window.confirm(`Move order #${id} to ${status}?`)) return;

        Api.patch(`/orders/${id}/status`, { status })
            .then(() => {
                if (window.Toast) Toast.success(`Order moved to ${status}`);
                this.loadOrders();
            })
            .catch((error) => {
                if (window.Toast) Toast.fromResponse(error, "Could not update order");
            });
    },

    handleOfferAction(event) {
        const button = event.target.closest("[data-offer-action]");
        if (!button) return;

        const id = button.dataset.id;
        const action = button.dataset.action;

        if (action === "accept") {
            this.openAcceptModal(id);
            return;
        }

        if (action === "counter") {
            this.openCounterModal(id);
            return;
        }

        const labels = {
            withdraw: "Withdraw this offer?",
            reject: "Reject this offer?",
        };
        if (!window.confirm(labels[action] || "Continue?")) return;

        Api.post(`/offers/${id}/${action}`)
            .then(() => {
                if (window.Toast) Toast.success(`Offer ${action === "reject" ? "rejected" : "withdrawn"}`);
                this.loadOffers();
            })
            .catch((error) => {
                if (window.Toast) Toast.fromResponse(error, `Could not ${action} offer`);
            });
    },

    openAcceptModal(offerId) {
        const offer = this.offers.find((o) => o.id === offerId);
        if (!offer) return;

        const modal = this.container.querySelector("#acceptModal");
        const idInput = this.container.querySelector("#acceptOfferId");
        const summary = this.container.querySelector("#acceptModalSummary");
        const listing = this.listingCache[offer.listingId] || {};

        if (idInput) idInput.value = offer.id;
        if (summary) {
            summary.textContent = `${listing.cropName || "Crop"} · ${this.number(offer.offeredQuantity)} units @ ৳${this.money(offer.offeredPrice)}/unit`;
        }

        const form = this.container.querySelector("#acceptForm");
        if (form) form.reset();

        if (modal) this.openModal(modal);
    },

    openCounterModal(offerId) {
        const offer = this.offers.find((o) => o.id === offerId);
        if (!offer) return;

        const modal = this.container.querySelector("#counterModal");
        const idInput = this.container.querySelector("#counterOfferId");
        const summary = this.container.querySelector("#counterModalListing");
        const listing = this.listingCache[offer.listingId] || {};

        if (idInput) idInput.value = offer.id;
        if (summary) {
            summary.textContent = `${listing.cropName || "Crop"} · current offer ${this.number(offer.offeredQuantity)} units @ ৳${this.money(offer.offeredPrice)}/unit`;
        }

        const quantity = this.container.querySelector("#counterQuantity");
        const price = this.container.querySelector("#counterPrice");
        if (quantity) quantity.value = offer.offeredQuantity;
        if (price) price.value = offer.offeredPrice;

        if (modal) this.openModal(modal);
    },

    async handleAcceptSubmit(event) {
        const form = this.container.querySelector("#acceptForm");
        if (!form) return;
        event.preventDefault();

        const offerId = this.value("#acceptOfferId");
        const deliveryAddress = this.value("#acceptDeliveryAddress");
        if (!deliveryAddress.trim()) {
            if (window.Toast) Toast.error("Enter a delivery address");
            return;
        }

        try {
            await Api.post("/orders", { offerId, deliveryAddress });
            if (window.Toast) Toast.success("Order placed");
            this.closeModal(this.container.querySelector("#acceptModal"));
            this.load();
        } catch (error) {
            if (window.Toast) Toast.fromResponse(error, "Could not place order");
        }
    },

    async handleCounterSubmit(event) {
        const form = this.container.querySelector("#counterForm");
        if (!form) return;
        event.preventDefault();

        const offerId = this.value("#counterOfferId");
        const body = {
            offeredQuantity: Number(this.value("#counterQuantity")),
            offeredPrice: Number(this.value("#counterPrice")),
        };

        if (!body.offeredQuantity || body.offeredQuantity <= 0 || !body.offeredPrice || body.offeredPrice <= 0) {
            if (window.Toast) Toast.error("Enter valid quantity and price");
            return;
        }

        try {
            await Api.post(`/offers/${offerId}/counter`, body);
            if (window.Toast) Toast.success("Counter offer sent");
            this.closeModal(this.container.querySelector("#counterModal"));
            this.loadOffers();
        } catch (error) {
            if (window.Toast) Toast.fromResponse(error, "Could not send counter offer");
        }
    },

    renderOrders(orders) {
        const wrap = this.container.querySelector("#ordersTableWrap");
        const count = this.container.querySelector("#ordersCount");
        if (!wrap) return;

        if (count) count.textContent = String(orders.length);
        if (!orders.length) {
            wrap.innerHTML = '<div class="empty-state">No order commitments.</div>';
            return;
        }

        const rows = orders
            .map((order) => {
                const transitions = this.TRANSITIONS[order.orderStatus] || [];
                const actions = transitions
                    .map(
                        (next) =>
                            `<button type="button" class="btn btn-sm btn-${next === "CANCELLED" ? "danger" : "primary"}" data-order-action data-id="${this.esc(order.id)}" data-status="${next}">${this.esc(next.replaceAll("_", " "))}</button>`
                    )
                    .join("");
                const chatButton = this.isAdmin
                    ? ""
                    : `<button type="button" class="btn btn-sm btn-secondary" data-order-chat data-id="${this.esc(order.id)}">💬 Chat</button>`;

                return `
                    <tr>
                        <td class="font-mono" style="font-size: 0.8rem;">#${this.esc(order.id || "")}</td>
                        <td class="font-semibold">${this.esc(order.cropName || "—")}</td>
                        <td>${this.number(order.agreedQuantity)}</td>
                        <td>৳${this.money(order.agreedPricePerUnit)}</td>
                        <td class="font-semibold">৳${this.money(order.totalAmount)}</td>
                        <td>${this.date(order.createdAt)}</td>
                        <td>${this.statusBadge(order.orderStatus)}</td>
                        <td>
                            <div class="flex gap-2">${chatButton}${actions || '<span class="text-muted">—</span>'}
                            </div>
                        </td>
                    </tr>`;
            })
            .join("");

        wrap.innerHTML = `
            <div class="table-scroll">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Order</th>
                            <th>Crop</th>
                            <th>Qty</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>`;
    },

    renderOffers(offers) {
        const wrap = this.container.querySelector("#offerList");
        const count = this.container.querySelector("#offersCount");
        if (!wrap) return;

        if (count) count.textContent = String(offers.length);
        if (!offers.length) {
            wrap.innerHTML = '<div class="empty-state">No offers to review.</div>';
            return;
        }

        const rows = offers
            .map((offer) => {
                const listing = this.listingCache[offer.listingId] || {};
                const cropName = listing.cropName || "—";
                const offered = this.number(offer.offeredQuantity);
                const price = this.money(offer.offeredPrice);
                const pending = offer.status === "OFFERED";

                let actions = '<span class="text-muted">—</span>';
                if (pending) {
                    if (this.role === "FARMER") {
                        actions = `
                            <button type="button" class="btn btn-sm btn-primary" data-offer-action="accept" data-id="${this.esc(offer.id)}">Accept</button>
                            <button type="button" class="btn btn-sm btn-secondary" data-offer-action="counter" data-id="${this.esc(offer.id)}">Counter</button>
                            <button type="button" class="btn btn-sm btn-danger" data-offer-action="reject" data-id="${this.esc(offer.id)}">Reject</button>`;
                    } else if (this.role === "BUYER") {
                        actions = `
                            <button type="button" class="btn btn-sm btn-danger" data-offer-action="withdraw" data-id="${this.esc(offer.id)}">Withdraw</button>`;
                    }
                }

                return `
                    <div class="flex items-center justify-between gap-4 py-3" style="border-bottom: 1px solid var(--color-border);">
                        <div class="min-w-0">
                            <p class="mb-0 font-semibold" style="font-weight: 600;">${this.esc(cropName)}</p>
                            <p class="text-muted mb-0" style="font-size: 0.8rem;">
                                ${offered} units @ ৳${price}/unit · <span class="font-mono">#${this.esc(offer.id || "")}</span>
                            </p>
                        </div>
                        <div class="flex items-center gap-3">
                            ${this.statusBadge(offer.status)}
                            <div class="flex gap-2">${actions}</div>
                        </div>
                    </div>`;
            })
            .join("");

        wrap.innerHTML = rows;
    },

    async ensureListing(listingId) {
        if (!listingId || this.listingCache[listingId]) return;
        try {
            const res = await Api.get(`/produce/${listingId}`);
            this.listingCache[listingId] = res.data || {};
        } catch (error) {
            this.listingCache[listingId] = {};
        }
    },

    statusBadge(status) {
        const cls = {
            PENDING: "badge-info",
            CONFIRMED: "badge-success",
            IN_TRANSIT: "badge-warning",
            DELIVERED: "badge-success",
            CANCELLED: "badge-error",
            DISPUTED: "badge-warning",
            OFFERED: "badge-info",
            ACCEPTED: "badge-success",
            REJECTED: "badge-error",
            EXPIRED: "badge-warning",
        };
        return `<span class="badge ${cls[status] || "badge-info"}">${this.esc(status || "")}</span>`;
    },

    openModal(modal) {
        if (!modal) return;
        modal.classList.add("open");
        modal.setAttribute("aria-hidden", "false");
    },

    closeModal(modal) {
        if (!modal) return;
        modal.classList.remove("open");
        modal.setAttribute("aria-hidden", "true");
    },

    value(selector) {
        const el = this.container.querySelector(selector);
        return el ? el.value : "";
    },

    number(value) {
        return Number(value || 0).toLocaleString("en-IN");
    },

    money(value) {
        return Number(value || 0).toLocaleString("en-IN", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        });
    },

    date(iso) {
        return iso
            ? new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })
            : "—";
    },

    esc(value) {
        return String(value)
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    },
};