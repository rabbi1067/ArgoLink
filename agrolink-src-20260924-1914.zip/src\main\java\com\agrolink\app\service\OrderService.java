package com.agrolink.app.service;

import com.agrolink.app.dto.AcceptOfferRecord;
import com.agrolink.app.dto.OrderResponseRecord;
import com.agrolink.app.model.OrderStatus;

import java.util.List;

public interface OrderService {

    OrderResponseRecord acceptOffer(String userId, AcceptOfferRecord request);

    OrderResponseRecord getOrderById(String orderId, String userId, boolean isAdmin);

    List<OrderResponseRecord> getBuyerOrders(String buyerId);

    List<OrderResponseRecord> getFarmerOrders(String farmerId);

    List<OrderResponseRecord> getOrdersByStatus(OrderStatus status);

    OrderResponseRecord updateOrderStatus(String orderId, String userId, boolean isAdmin, OrderStatus newStatus);
}