package com.agrolink.app.service.impl;

import com.agrolink.app.config.CacheConfig;
import com.agrolink.app.dto.DailyForecastDTO;
import com.agrolink.app.dto.WeatherForecastDTO;
import com.agrolink.app.exception.ResourceNotFoundException;
import com.agrolink.app.service.WeatherService;
import com.agrolink.app.util.BangladeshLocationRegions;
import com.agrolink.app.util.BangladeshLocationRegions.GeoPoint;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Bangladeshi district weather backed by <strong>Open-Meteo</strong>
 * (https://open-meteo.com) — free, key-less forecast data.
 *
 * <p>Design:</p>
 * <ul>
 *   <li>One 7-day payload is cached per district ({@code weatherData}, 1 h, Caffeine);
 *       shorter requests are sliced from it, so all callers share one upstream call.</li>
 *   <li>The cache is used programmatically (not via {@code @Cacheable}) because
 *       {@code getForecastCached → getForecast} is a self-invocation that Spring's proxy would
 *       bypass, and because the Refresh button needs explicit eviction.</li>
 *   <li><strong>Honesty contract:</strong> we never invent numbers. If the live call fails we serve the
 *       last successful forecast flagged {@code stale=true}; if there is none, an explicit
 *       {@code fallback=true} payload with an empty list and a clear message (the UI shows a
 *       retry state, never 0.0°C).</li>
 * </ul>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class WeatherServiceImpl implements WeatherService {

    private static final String OPEN_METEO = "https://api.open-meteo.com/v1/forecast";
    private static final String PROVIDER = "Open-Meteo (open-meteo.com · CC-BY-4.0)";
    private static final String UNITS = "°C · mm · km/h · WMO";
    private static final int MAX_DAYS = 7;
    private static final Duration REFRESH_COOLDOWN = Duration.ofSeconds(30);
    private static final String DISCLAIMER = "Source: " + PROVIDER + " — free forecast for planning hints only, "
            + "not official Bangladesh Meteorological Department guidance. Verify locally before "
            + "acting on any crop decision.";

    private final ObjectMapper objectMapper;
    private final CacheManager cacheManager;

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(8))
            .build();
    /** Last successful forecast per district — served (flagged stale) if a live call fails. */
    private final Map<String, WeatherForecastDTO> lastGood = new ConcurrentHashMap<>();
    private final Map<String, Instant> lastRefresh = new ConcurrentHashMap<>();
    private final Map<String, Object> locks = new ConcurrentHashMap<>();

    // ------------------------------------------------------------------ public API

    @Override
    public WeatherForecastDTO getForecast(String district, int days) {
        String name = resolve(district);
        return limit(load(name), days);
    }

    @Override
    public WeatherForecastDTO getForecastCached(String district, int days) {
        return getForecast(district, days);
    }

    @Override
    public WeatherForecastDTO refreshForecast(String district, int days) {
        String name = resolve(district);
        Instant now = Instant.now();
        Instant previous = lastRefresh.get(name);
        boolean allowed = previous == null || Duration.between(previous, now).compareTo(REFRESH_COOLDOWN) >= 0;
        if (allowed) {
            lastRefresh.put(name, now);
            Cache cache = cacheManager.getCache(CacheConfig.CACHE_WEATHER_DATA);
            if (cache != null) {
                cache.evict(name);
            }
        }
        return limit(load(name), days);
    }

    @Override
    public List<String> getDistricts() {
        return BangladeshLocationRegions.allDistricts();
    }

    @Override
    public WeatherForecastDTO getForecastByLocation(double lat, double lon, int days) {
        String nearest = BangladeshLocationRegions.nearestDistrict(lat, lon)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "No known Bangladeshi district within 400 km of " + lat + ", " + lon + "."));
        return getForecast(nearest, days);
    }

    // ------------------------------------------------------------------ loading / caching

    private String resolve(String district) {
        return BangladeshLocationRegions.normalize(district)
                .orElseThrow(() -> new ResourceNotFoundException("Unknown district '" + district + "'."));
    }

    private WeatherForecastDTO load(String name) {
        Cache cache = cacheManager.getCache(CacheConfig.CACHE_WEATHER_DATA);
        // Per-district lock: concurrent requests for the same district trigger one upstream call.
        synchronized (locks.computeIfAbsent(name, k -> new Object())) {
            if (cache != null) {
                WeatherForecastDTO hit = cache.get(name, WeatherForecastDTO.class);
                if (hit != null) {
                    return hit;
                }
            }
            WeatherForecastDTO live = fetchLive(name);
            if (live != null) {
                if (cache != null) {
                    cache.put(name, live);
                }
                lastGood.put(name, live);
                return live;
            }
            WeatherForecastDTO old = lastGood.get(name);
            return old != null ? asStale(old) : unavailable(name);
        }
    }

    /** Returns a fresh forecast, or {@code null} if anything about the live call went wrong. */
    private WeatherForecastDTO fetchLive(String name) {
        GeoPoint p = BangladeshLocationRegions.coordinatesOf(name).orElseThrow();
        String division = BangladeshLocationRegions.divisionOf(name).orElse("Bangladesh");
        String url = OPEN_METEO + "?latitude=" + p.latitude() + "&longitude=" + p.longitude()
                + "&current=temperature_2m,weather_code,wind_speed_10m,rain,is_day"
                + "&daily=temperature_2m_max,temperature_2m_min,rain_sum,precipitation_probability_max,"
                + "wind_speed_10m_max,weather_code"
                + "&timezone=Asia%2FDhaka&wind_speed_unit=kmh&forecast_days=" + MAX_DAYS;
        try {
            HttpResponse<String> resp = httpClient.send(
                    HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(15)).GET().build(),
                    HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200) {
                log.warn("Open-Meteo returned HTTP {} for {}", resp.statusCode(), name);
                return null;
            }
            JsonNode root = objectMapper.readTree(resp.body());
            JsonNode daily = root.path("daily");
            JsonNode times = daily.path("time");
            if (!times.isArray() || times.size() == 0) {
                log.warn("Open-Meteo returned no daily data for {}", name);
                return null;
            }
            JsonNode tMax = daily.path("temperature_2m_max");
            JsonNode tMin = daily.path("temperature_2m_min");
            JsonNode pProb = daily.path("precipitation_probability_max");
            JsonNode rain = daily.path("rain_sum");
            JsonNode wind = daily.path("wind_speed_10m_max");
            JsonNode wmo = daily.path("weather_code");

            List<DailyForecastDTO> rows = new ArrayList<>();
            for (int i = 0; i < times.size() && i < MAX_DAYS; i++) {
                Integer code = intAt(wmo, i);
                rows.add(new DailyForecastDTO(
                        LocalDate.parse(times.get(i).asText()),
                        numAt(tMax, i), numAt(tMin, i), intAt(pProb, i),
                        numAt(rain, i), numAt(wind, i), code, describe(code)));
            }
            if (rows.stream().noneMatch(r -> r.tempMaxC() != null)) {
                log.warn("Open-Meteo payload for {} had no temperatures", name);
                return null;
            }
            return new WeatherForecastDTO(name, division, p.latitude(), p.longitude(), rows.size(), UNITS,
                    parseCurrent(root.path("current")), List.copyOf(rows), Instant.now(), PROVIDER,
                    false, false, DISCLAIMER);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            log.warn("Weather fetch interrupted for {}", name);
            return null;
        } catch (Exception ex) {
            log.warn("Weather fetch failed for {}: {}", name, ex.toString());
            return null;
        }
    }

    private WeatherForecastDTO.Current parseCurrent(JsonNode cur) {
        Double temp = numNode(cur.path("temperature_2m"));
        if (temp == null) {
            return null;
        }
        Integer code = intNode(cur.path("weather_code"));
        JsonNode isDay = cur.path("is_day");
        Boolean day = (isDay.isMissingNode() || isDay.isNull()) ? null : isDay.asInt() == 1;
        return new WeatherForecastDTO.Current(temp, numNode(cur.path("wind_speed_10m")),
                numNode(cur.path("rain")), code, describe(code), day, cur.path("time").asText(null));
    }

    // ------------------------------------------------------------------ fallbacks

    private WeatherForecastDTO asStale(WeatherForecastDTO o) {
        return new WeatherForecastDTO(o.district(), o.division(), o.latitude(), o.longitude(), o.days(), o.units(),
                o.current(), o.daily(), o.generatedAt(), o.provider(), false, true,
                "Live update failed, so this is the last successfully loaded forecast. " + DISCLAIMER);
    }

    private WeatherForecastDTO unavailable(String name) {
        GeoPoint p = BangladeshLocationRegions.coordinatesOf(name).orElseThrow();
        return new WeatherForecastDTO(name, BangladeshLocationRegions.divisionOf(name).orElse("Bangladesh"),
                p.latitude(), p.longitude(), 0, UNITS, null, List.of(), Instant.now(), PROVIDER, true, false,
                "Live forecast is temporarily unavailable. We never show made-up numbers — retry in a moment, "
                        + "or check the Bangladesh Meteorological Department / local agriculture office.");
    }

    private WeatherForecastDTO limit(WeatherForecastDTO full, int days) {
        int bounded = Math.min(Math.max(days, 1), MAX_DAYS);
        if (full.daily().size() <= bounded) {
            return full;
        }
        return new WeatherForecastDTO(full.district(), full.division(), full.latitude(), full.longitude(), bounded,
                full.units(), full.current(), List.copyOf(full.daily().subList(0, bounded)), full.generatedAt(),
                full.provider(), full.fallback(), full.stale(), full.disclaimer());
    }

    // ------------------------------------------------------------------ JSON helpers

    private static Double numNode(JsonNode n) {
        if (n == null || n.isMissingNode() || n.isNull() || !n.isNumber()) {
            return null;
        }
        double v = n.asDouble();
        return Double.isNaN(v) ? null : v;
    }

    private static Integer intNode(JsonNode n) {
        return (n == null || n.isMissingNode() || n.isNull() || !n.isNumber()) ? null : n.asInt();
    }

    private static Double numAt(JsonNode arr, int i) {
        return numNode(arr.get(i));
    }

    private static Integer intAt(JsonNode arr, int i) {
        return intNode(arr.get(i));
    }

    private static String describe(Integer code) {
        if (code == null) {
            return "Variable";
        }
        return switch (code) {
            case 0 -> "Clear sky";
            case 1 -> "Mainly clear";
            case 2 -> "Partly cloudy";
            case 3 -> "Overcast";
            case 45, 48 -> "Fog";
            case 51, 53, 55 -> "Drizzle";
            case 56, 57 -> "Freezing drizzle";
            case 61, 63, 65 -> "Rain";
            case 66, 67 -> "Freezing rain";
            case 71, 73, 75 -> "Snow";
            case 77 -> "Snow grains";
            case 80, 81, 82 -> "Rain showers";
            case 85, 86 -> "Snow showers";
            case 95 -> "Thunderstorm";
            case 96, 99 -> "Thunderstorm with hail";
            default -> "Variable";
        };
    }
}