package com.agrolink.app.controller.api;

import com.agrolink.app.dto.ApiResponse;
import com.agrolink.app.dto.WeatherForecastDTO;
import com.agrolink.app.service.WeatherService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/weather")
@RequiredArgsConstructor
public class WeatherController {

    private final WeatherService weatherService;

    /** All 64 supported Bangladeshi districts — dropdown/filter source. */
    @GetMapping("/districts")
    public ResponseEntity<ApiResponse<List<String>>> districts() {
        return ResponseEntity.ok(ApiResponse.ok("Districts loaded", weatherService.getDistricts()));
    }

    /** Device-location forecast: snap lat/lon to nearest district, then forecast. */
    @GetMapping("/nearby")
    public ResponseEntity<ApiResponse<WeatherForecastDTO>> nearby(
            @RequestParam double lat,
            @RequestParam double lon,
            @RequestParam(value = "days", required = false, defaultValue = "7") int days) {
        return ResponseEntity.ok(ApiResponse.ok(
                "Location forecast retrieved", weatherService.getForecastByLocation(lat, lon, days)));
    }

    /**
     * District forecast (1..7 days). {@code refresh=true} clears that district's cache entry
     * and pulls live data (throttled server-side) — used by the Refresh button.
     */
    @GetMapping("/forecast")
    public ResponseEntity<ApiResponse<WeatherForecastDTO>> forecast(
            @RequestParam(value = "district", required = false, defaultValue = "Dhaka") String district,
            @RequestParam(value = "days", required = false, defaultValue = "7") int days,
            @RequestParam(value = "refresh", required = false, defaultValue = "false") boolean refresh) {
        WeatherForecastDTO forecast = refresh
                ? weatherService.refreshForecast(district, days)
                : weatherService.getForecastCached(district, days);
        return ResponseEntity.ok(ApiResponse.ok("Forecast retrieved", forecast));
    }
}