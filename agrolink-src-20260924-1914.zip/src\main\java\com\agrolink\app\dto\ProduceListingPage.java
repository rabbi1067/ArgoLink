package com.agrolink.app.dto;

import java.util.List;

/** One page of marketplace search results. {@code page} is zero-based. */
public record ProduceListingPage(
        List<ProduceListingResponse> items,
        int page,
        int size,
        long totalItems,
        int totalPages,
        boolean hasNext,
        boolean hasPrevious) {
}