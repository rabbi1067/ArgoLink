/* ------------------------------------------------------------------
 * Shared weather helpers. The identical block sits at the top of
 * overview.js and weather.js; whichever loads first defines it.
 * (Optional: move it into its own weather-util.js and load it first.)
 * ------------------------------------------------------------------ */
(function () {
    if (window.WeatherUtil) return;

    const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const EVT = "agrolink:weather-district";
    const KEY = "agrolink.weather.district";
    const DEFAULT_DISTRICT = "Dhaka";
    let districtsPromise = null;

    const esc = (v) =>
        String(v === null || v === undefined ? "" : v)
            .replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;").replaceAll("'", "&#039;");

    const fmt = (v, digits = 1) =>
        v === null || v === undefined || Number.isNaN(Number(v)) ? "--" : Number(v).toFixed(digits);

    function toDate(iso) {
        const [y, m, d] = String(iso || "").slice(0, 10).split("-").map(Number);
        const dt = new Date(y, (m || 1) - 1, d || 1);
        return Number.isNaN(dt.getTime()) ? null : dt;
    }

    /** "Wed, 23 Sep" */
    function shortLabel(iso) {
        const dt = toDate(iso);
        return dt ? `${DAYS[dt.getDay()].slice(0, 3)}, ${dt.getDate()} ${MONTHS[dt.getMonth()]}` : "—";
    }

    /** "Wednesday, 23 Sep" */
    function longLabel(iso) {
        const dt = toDate(iso);
        return dt ? `${DAYS[dt.getDay()]}, ${dt.getDate()} ${MONTHS[dt.getMonth()]}` : "—";
    }

    function todayIso() {
        const n = new Date();
        return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, "0")}-${String(n.getDate()).padStart(2, "0")}`;
    }

    function updatedLabel(iso) {
        const dt = iso ? new Date(iso) : null;
        if (!dt || Number.isNaN(dt.getTime())) return "—";
        return `${dt.getDate()} ${MONTHS[dt.getMonth()]}, ${String(dt.getHours()).padStart(2, "0")}:${String(dt.getMinutes()).padStart(2, "0")}`;
    }

    /** Open-Meteo WMO weather code → emoji icon. */
    function icon(code, isDay) {
        if (code === null || code === undefined) return "🌡️";
        const c = Number(code);
        if (c === 0) return isDay === false ? "🌙" : "☀️";
        if (c === 1) return isDay === false ? "🌙" : "🌤️";
        if (c === 2) return "⛅";
        if (c === 3) return "☁️";
        if (c === 45 || c === 48) return "🌫️";
        if (c >= 51 && c <= 57) return "🌦️";
        if ((c >= 61 && c <= 67) || (c >= 80 && c <= 82)) return "🌧️";
        if ((c >= 71 && c <= 77) || c === 85 || c === 86) return "❄️";
        if (c >= 95) return "⛈️";
        return "🌡️";
    }

    /** Smart agricultural badge for one forecast day (priority order). */
    function advisory(day) {
        const rain = day.rainSumMm, wind = day.windMaxKmh, tmax = day.tempMaxC, code = day.weatherCode;
        if (rain === null && tmax === null) return null;
        if ((code !== null && code >= 95) || (wind !== null && wind >= 40)) {
            return { label: "⚠️ Storm Alert", cls: "badge-error" };
        }
        if (rain !== null && rain > 5) return { label: "🌧️ Rain Warning", cls: "badge-warning" };
        if (tmax !== null && tmax >= 36) return { label: "🔥 Heat Stress", cls: "badge-warning" };
        if (rain !== null && rain <= 1) return { label: "🌾 Good for Harvest", cls: "badge-success" };
        return { label: "🌦️ Light Rain – Plan Ahead", cls: "badge-info" };
    }

    /** Every time the page opens it starts on Dhaka (no remembered district). */
    function getDistrict() {
        return DEFAULT_DISTRICT;
    }

    /** Broadcast so any other mounted weather view updates instantly (nothing is remembered). */
    function setDistrict(district, source) {
        window.dispatchEvent(new CustomEvent(EVT, { detail: { district, source: source || "" } }));
    }

    function getDistricts() {
        if (!districtsPromise) {
            districtsPromise = Api.get("/weather/districts")
                .then((res) => res.data || [])
                .catch(() => { districtsPromise = null; return []; });
        }
        return districtsPromise;
    }

    function matchDistrict(list, wanted) {
        const w = String(wanted || "").toLowerCase();
        return list.find((d) => d.toLowerCase() === w) || (list.includes(DEFAULT_DISTRICT) ? DEFAULT_DISTRICT : list[0]);
    }

    /** Resolve a possibly-unknown district name to a valid one. */
    async function resolveDistrict(wanted) {
        const list = await getDistricts();
        return list.length ? matchDistrict(list, wanted) : wanted;
    }

    /** Fill a <select> with all districts and select the best match; returns the effective district. */
    async function fillDistricts(select, wanted) {
        const list = await getDistricts();
        select.innerHTML = "";
        if (!list.length) {
            const opt = new Option("Districts unavailable", "");
            opt.disabled = true;
            select.add(opt);
            return wanted;
        }
        list.forEach((d) => select.add(new Option(d, d)));
        const chosen = matchDistrict(list, wanted);
        select.value = chosen;
        return chosen;
    }

    window.WeatherUtil = {
        EVT, DEFAULT_DISTRICT, esc, fmt, shortLabel, longLabel, todayIso, updatedLabel,
        icon, advisory, getDistrict, setDistrict, resolveDistrict, fillDistricts,
    };
})();

/* ------------------------------------------------------------------ */

window.Pages = window.Pages || {};

window.Pages.overview = {
    container: null,
    role: "BUYER",
    district: "Dhaka",
    wxReq: 0,
    _onDistrict: null,

    init(container) {
        this.container = container;
        const user = window.Api && Api.getUser ? Api.getUser() : null;
        this.role = user && user.role ? user.role : "BUYER";
        this.bindRefresh();
        this.initWeather();
        this.load();
    },

    bindRefresh() {
        const button = this.container.querySelector("[data-overview-refresh]");
        if (button) {
            button.addEventListener("click", () => {
                this.load(true);
                this.loadWeather(true);
            });
        }
    },

    isAdmin() {
        return this.role === "ADMIN" || this.role === "SUPER_ADMIN";
    },

    /* ------------------------------------------------------------ weather widget */

    async initWeather() {
        const U = window.WeatherUtil;
        const widget = this.container.querySelector("#overview-weather-widget");
        if (!widget) return; // overview.html not updated yet

        const select = widget.querySelector("#overview-district-select");
        if (select) {
            if (this.isAdmin()) {
                // Admin location override: any of the 64 districts, synced with the Weather page.
                select.hidden = false;
                this.district = await U.fillDistricts(select, U.getDistrict());
                select.addEventListener("change", () => {
                    if (!select.value) return;
                    this.district = select.value;
                    U.setDistrict(this.district, "overview");
                    this.loadWeather();
                });
            } else {
                select.hidden = true;
                this.district = await U.resolveDistrict(U.getDistrict());
            }
        } else {
            this.district = await U.resolveDistrict(U.getDistrict());
        }

        // Instant sync when the district is changed on the 7-day Weather page.
        if (this._onDistrict) window.removeEventListener(U.EVT, this._onDistrict);
        this._onDistrict = (e) => {
            if (!this.container || !this.container.isConnected) {
                window.removeEventListener(U.EVT, this._onDistrict);
                return;
            }
            if (!e.detail || e.detail.source === "overview" || !e.detail.district) return;
            this.district = e.detail.district;
            const sel = this.container.querySelector("#overview-district-select");
            if (sel && !sel.hidden) sel.value = this.district;
            this.loadWeather();
        };
        window.addEventListener(U.EVT, this._onDistrict);

        this.loadWeather();
    },

    async loadWeather(refresh = false) {
        const U = window.WeatherUtil;
        const body = this.container.querySelector("#overview-weather-body");
        if (!body) return;

        const id = ++this.wxReq;
        body.innerHTML = '<div class="empty-state">Loading weather...</div>';

        try {
            const url = `/weather/forecast?district=${encodeURIComponent(this.district)}&days=7` + (refresh ? "&refresh=true" : "");
            const res = await Api.get(url);
            if (id !== this.wxReq) return;
            const d = res.data;
            if (!d || d.fallback || !d.daily || !d.daily.length) {
                this.renderWeatherUnavailable(body, d && d.disclaimer);
            } else {
                this.renderWeather(body, d);
            }
        } catch (e) {
            if (id !== this.wxReq) return;
            this.renderWeatherUnavailable(body, null);
        }
    },

    renderWeather(body, d) {
        const U = window.WeatherUtil;
        const today = d.daily[0];
        const cur = d.current || {};
        const code = cur.weatherCode !== null && cur.weatherCode !== undefined ? cur.weatherCode : today.weatherCode;
        const desc = cur.description || today.description || "";
        const wind = cur.windKmh !== null && cur.windKmh !== undefined ? cur.windKmh : today.windMaxKmh;
        const place = [d.district, d.division && d.division !== d.district ? d.division : null].filter(Boolean).join(", ");

        body.innerHTML = `
            <div class="wx-now">
                <span class="wx-now-icon">${U.icon(code, cur.day)}</span>
                <div>
                    <div class="wx-now-temp">${U.fmt(cur.temperatureC)}°C</div>
                    <div class="wx-now-desc">${U.esc(desc)}</div>
                </div>
            </div>
            <div class="wx-now-info">
                <p class="wx-now-date">${U.esc(U.longLabel(today.date || U.todayIso()))}</p>
                <p class="text-muted mb-0">📍 ${U.esc(place)}</p>
                <div class="wx-chips">
                    <span>💧 Rain ${U.fmt(today.rainSumMm)} mm</span>
                    <span>💨 Wind ${U.fmt(wind)} km/h</span>
                </div>
                ${d.stale ? '<p class="text-muted wx-note">Live update failed — showing the last saved forecast.</p>' : ""}
            </div>`;
    },

    renderWeatherUnavailable(body, message) {
        const U = window.WeatherUtil;
        body.innerHTML = `
            <div class="empty-state">
                <p class="mb-2">${U.esc(message || "Weather is unavailable right now.")}</p>
                <button type="button" class="btn btn-primary" data-wx-retry>Try again</button>
            </div>`;
        const retry = body.querySelector("[data-wx-retry]");
        if (retry) retry.addEventListener("click", () => this.loadWeather(true));
    },

    /* ------------------------------------------------------------ existing overview */

    async load(force) {
        this.setGreeting();

        const statsEl = this.container.querySelector("#overviewStats");
        const activityEl = this.container.querySelector("#overviewActivity");

        try {
            const stats = await this.fetchStats();
            statsEl.innerHTML = stats.map((card) => this.statCard(card)).join("");

            const orders = await this.fetchActivity();
            this.renderActivity(orders);
        } catch (error) {
            statsEl.innerHTML = '<div class="empty-state">Could not load metrics</div>';
            if (activityEl) {
                activityEl.innerHTML = '<div class="empty-state">Could not load activity</div>';
            }
            if (window.Toast) {
                Toast.fromResponse(error, "Could not load overview");
            }
        }
    },

    setGreeting() {
        const user = window.Api && Api.getUser ? Api.getUser() : null;
        const name = user && user.name ? user.name.split(" ")[0] : "there";
        const hour = new Date().getHours();
        const part = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";

        const greeting = this.container.querySelector("#overviewGreeting");
        const dateEl = this.container.querySelector("#overviewDate");
        if (greeting) greeting.textContent = `${part}, ${name}.`;
        if (dateEl) {
            dateEl.textContent = new Date().toLocaleDateString("en-IN", {
                weekday: "long",
                day: "numeric",
                month: "long",
                year: "numeric",
            });
        }
    },

    async fetchStats() {
        if (this.role === "FARMER") {
            const [listingsRes, ordersRes, offersRes] = await Promise.all([
                Api.get("/produce/my"),
                Api.get("/orders/my", { as: "FARMER" }),
                Api.get("/offers/my", { as: "FARMER" }),
            ]);

            const listings = listingsRes.data || [];
            const orders = ordersRes.data || [];
            const offers = offersRes.data || [];

            const active = listings.filter((l) => l.status === "ACTIVE").length;
            const revenue = orders.reduce((sum, o) => sum + Number(o.totalAmount || 0), 0);

            return [
                { label: "My Listings", value: listings.length, icon: "🌾" },
                { label: "Active Listings", value: active, icon: "✅" },
                { label: "My Orders", value: orders.length, icon: "📦" },
                { label: "Live Offers", value: offers.filter((o) => o.status === "OFFERED").length, icon: "💬" },
            ];
        }

        if (this.role === "ADMIN" || this.role === "SUPER_ADMIN") {
            const res = await Api.get("/analytics/overview");
            const d = res.data || {};
            return [
                { label: "Total Users", value: d.totalUsers, icon: "👥" },
                { label: "Total Listings", value: d.totalListings, icon: "🌾" },
                { label: "Active Listings", value: d.activeListings, icon: "✅" },
                { label: "Total Orders", value: d.totalOrders, icon: "📦" },
            ];
        }

        const [produceRes, ordersRes, offersRes] = await Promise.all([
            Api.get("/produce/listings"),
            Api.get("/orders/my", { as: "BUYER" }),
            Api.get("/offers/my", { as: "BUYER" }),
        ]);

        const orders = ordersRes.data || [];
        const commitment = orders.reduce((sum, o) => sum + Number(o.totalAmount || 0), 0);

        return [
            { label: "Available Crops", value: (produceRes.data || []).length, icon: "🌾" },
            { label: "My Orders", value: orders.length, icon: "📦" },
            { label: "Active Offers", value: (offersRes.data || []).filter((o) => o.status === "OFFERED").length, icon: "💬" },
            { label: "Committed Value", value: this.money(commitment), icon: "৳" },
        ];
    },

    async fetchActivity() {
        let orders = [];

        if (this.role === "ADMIN" || this.role === "SUPER_ADMIN") {
            const statuses = ["PENDING", "CONFIRMED", "IN_TRANSIT"];
            const results = await Promise.all(
                statuses.map((status) => Api.get(`/orders/status/${status}`))
            );
            const seen = new Set();
            results.forEach((res) => {
                (res.data || []).forEach((order) => {
                    if (!seen.has(order.id)) {
                        seen.add(order.id);
                        orders.push(order);
                    }
                });
            });
            orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        } else {
            const as = this.role === "FARMER" ? "FARMER" : "BUYER";
            const res = await Api.get("/orders/my", { as });
            orders = res.data || [];
        }

        return orders.slice(0, 8);
    },

    renderActivity(orders) {
        const wrap = this.container.querySelector("#overviewActivity");
        const count = this.container.querySelector("#overviewActivityCount");
        if (!wrap) return;

        if (count) count.textContent = String(orders.length);
        if (!orders.length) {
            wrap.innerHTML = '<div class="empty-state">No order activity yet.</div>';
            return;
        }

        wrap.innerHTML = orders
            .map(
                (order) => `
                    <div class="flex items-center justify-between gap-4 py-3" style="border-bottom: 1px solid var(--color-border);">
                        <div class="flex items-center gap-3 min-w-0">
                            <span class="icon-box">📦</span>
                            <div class="min-w-0">
                                <p class="mb-0 font-semibold" style="font-weight: 600;">${this.esc(order.cropName || "Order")}</p>
                                <p class="text-muted mb-0" style="font-size: 0.75rem;">
                                    ${this.shortDate(order.createdAt)} · #${this.esc(order.id || "")}
                                </p>
                            </div>
                        </div>
                        <div class="flex items-center gap-3">
                            <span class="font-semibold">৳${this.money(order.totalAmount)}</span>
                            ${this.statusBadge(order.orderStatus)}
                        </div>
                    </div>`
            )
            .join("");
    },

    statCard(card) {
        return `
            <div class="stat-card">
                <div class="stat-card-head">
                    <span class="stat-card-icon">${card.icon}</span>
                    <span class="badge badge-info">${this.esc(card.label)}</span>
                </div>
                <div class="stat-value">${card.value}</div>
            </div>`;
    },

    statusBadge(status) {
        const cls = {
            PENDING: "badge-info",
            CONFIRMED: "badge-success",
            IN_TRANSIT: "badge-warning",
            DELIVERED: "badge-success",
            CANCELLED: "badge-error",
            DISPUTED: "badge-warning",
        };
        return `<span class="badge ${cls[status] || "badge-info"}">${this.esc(status || "")}</span>`;
    },

    money(value) {
        return Number(value || 0).toLocaleString("en-IN", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        });
    },

    shortDate(iso) {
        return iso
            ? new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short" })
            : "—";
    },

    esc(value) {
        return String(value)
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    },
};