package com.agrolink.app.service;

import com.agrolink.app.dto.ProduceListingDTO;
import com.agrolink.app.dto.ProduceListingPage;
import com.agrolink.app.dto.ProduceListingRequest;
import com.agrolink.app.dto.ProduceListingResponse;
import com.agrolink.app.dto.ProduceSearchCriteria;
import com.agrolink.app.model.ListingStatus;

import java.math.BigDecimal;
import java.util.List;

public interface ProduceService {

    ProduceListingResponse create(String farmerId, ProduceListingRequest request);

    /** Owner (farmer) or a privileged user (ADMIN / SUPER_ADMIN) may edit. */
    ProduceListingResponse update(String id, String actorId, boolean privileged, ProduceListingRequest request);

    /**
     * Returns the listing if it is ACTIVE, or if the requester owns it / is privileged (admin).
     * Otherwise behaves as "not found" so draft listings are not leaked.
     */
    ProduceListingResponse getVisibleById(String id, String requesterId, boolean privileged);

    List<ProduceListingResponse> getMyListings(String farmerId);

    ProduceListingResponse changeStatus(String id, String actorId, boolean privileged, ListingStatus status);

    void delete(String id, String actorId, boolean privileged);

    /** Legacy unpaged search used by GET /listings (dashboard counters, landing page). */
    List<ProduceListingDTO> searchActive(String category, String cropName);

    /** Public marketplace search: filters, sorting and pagination. */
    ProduceListingPage search(ProduceSearchCriteria criteria);

    ProduceListingResponse adjustStock(String id, String actorId, boolean privileged, BigDecimal newAvailableQuantity);

    /** Every listing in every status (DRAFT..ARCHIVED), newest first, capped at 500. For admin management. */
    List<ProduceListingResponse> listAllForManagement();
}