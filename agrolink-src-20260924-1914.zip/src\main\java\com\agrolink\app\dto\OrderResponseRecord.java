package com.agrolink.app.dto;

import com.agrolink.app.model.Order;
import com.agrolink.app.model.OrderStatus;

import java.math.BigDecimal;
import java.time.Instant;

public record OrderResponseRecord(
        String id,
        String offerId,
        String buyerId,
        String farmerId,
        String cropName,
        BigDecimal agreedQuantity,
        BigDecimal agreedPricePerUnit,
        BigDecimal totalAmount,
        OrderStatus orderStatus,
        String deliveryAddress,
        Instant createdAt
) {
    public static OrderResponseRecord from(Order order) {
        return new OrderResponseRecord(
                order.getId(),
                order.getOfferId(),
                order.getBuyerId(),
                order.getFarmerId(),
                order.getCropName(),
                order.getAgreedQuantity(),
                order.getAgreedPricePerUnit(),
                order.getTotalAmount(),
                order.getOrderStatus(),
                order.getDeliveryAddress(),
                order.getCreatedAt()
        );
    }
}