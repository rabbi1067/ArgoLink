package com.agrolink.app.model;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.time.Instant;

/**
 * Digital invoice generated when an order is confirmed/delivered. Every amount
 * is BDT (BigDecimal). The QR payload is a signed verification token — it proves
 * the invoice/order exists with the backend, it does NOT imply a completed
 * payment (payment status is tracked separately on the order).
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "invoices")
@CompoundIndex(name = "invoices_order", def = "{'orderId': 1}")
public class Invoice {

    @Id
    private String id;

    /** Human-friendly, sequential-ish business number, e.g. AGR-INV-2026-000123. */
    @Indexed(unique = true)
    private String invoiceNumber;

    /** Dedupe by order for the invoice-or-order lookups.
     *  Name kept deliberately identical to the pre-existing Atlas index so
     *  Spring reuses it instead of raising IndexOptionsConflict (error 85). */
    @Indexed(name = "invoices_order")
    private String orderId;

    private String buyerId;   // Bill to
    private String farmerId;  // Bill from

    private String buyerName;
    private String farmerName     = "AgroLink Verified Farmer";
    private String buyerAddress;
    private String cropName;

    @NotNull(message = "Quantity is required")
    @DecimalMin(value = "0.01", message = "Quantity must be greater than zero")
    private BigDecimal quantity;

    @NotNull(message = "Unit price is required")
    @DecimalMin(value = "0.0", message = "Unit price cannot be negative")
    private BigDecimal unitPriceBt;

    private BigDecimal subtotalBt;
    private BigDecimal deliveryChargeBt;
    private BigDecimal taxBt;
    private BigDecimal discountBt;
    private BigDecimal totalBt;

    private String paymentStatus;

    private String deliveryAddress;

    /** Payment cutoff; e.g. 7 days after the invoice was (re)computed against the latest order. */
    private Instant dueDate;

    /** Random verification token embedded in the QR code. */
    @Indexed
    private String verificationToken;

    /** Secure HTTPS Cloudinary URL of the embedded QR code image; never binary. */
    private String qrCodeUrl;

    /** Optional secure HTTPS Cloudinary URL of an attached image (e.g. produce photo); never binary. */
    private String imageUrl;

    @CreatedDate
    private Instant createdAt;

    @LastModifiedDate
    private Instant updatedAt;
}
