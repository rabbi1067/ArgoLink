package com.agrolink.app.service.impl;

import com.agrolink.app.dto.AuthResponseRecord;
import com.agrolink.app.dto.CreateUserRecord;
import com.agrolink.app.dto.LoginRequestRecord;
import com.agrolink.app.dto.RegisterRequestRecord;
import com.agrolink.app.exception.BusinessRuleException;
import com.agrolink.app.exception.EntityConflictException;
import com.agrolink.app.exception.ResourceNotFoundException;
import com.agrolink.app.model.Role;
import com.agrolink.app.model.User;
import com.agrolink.app.repository.UserRepository;
import com.agrolink.app.service.AuthService;
import com.agrolink.app.service.JwtUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private static final String TOKEN_TYPE = "Bearer";

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtils jwtUtils;

    @Override
    public AuthResponseRecord register(RegisterRequestRecord request) {
        Role role = request.role() == null ? Role.BUYER : request.role();
        validateSelfRegistration(role);

        User user = buildAndSaveUser(
                request.name(), request.email(), request.password(),
                role, request.phone(), request.location()
        );
        return buildAuthResponse(issueToken(user), user);
    }

    @Override
    public AuthResponseRecord login(LoginRequestRecord request) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.email(), request.password())
            );
        } catch (Exception ex) {
            throw new BusinessRuleException("Invalid email or password", 401);
        }

        User user = findByEmail(request.email());
        return buildAuthResponse(issueToken(user), user);
    }

    @Override
    public AuthResponseRecord createUser(CreateUserRecord request) {
        if (request.role() == Role.SUPER_ADMIN) {
            throw new BusinessRuleException("Cannot create a SUPER_ADMIN through the management API", 403);
        }
        User user = buildAndSaveUser(
                request.name(), request.email(), request.password(),
                request.role(), request.phone(), request.location()
        );
        return buildAuthResponse(null, user);
    }

    @Override
    public java.util.List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public java.util.List<User> getUsersByRole(Role role) {
        return userRepository.findByRole(role);
    }

    @Override
    public User findByEmail(String email) {
        return userRepository.findByEmail(email.toLowerCase().trim())
                .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
    }

    @Override
    public User updateUserRole(String userId, Role role) {
        if (role == Role.SUPER_ADMIN) {
            throw new BusinessRuleException("Cannot assign SUPER_ADMIN through the management API", 403);
        }
        User user = findUserById(userId);
        user.setRole(role);
        return userRepository.save(user);
    }

    @Override
    public void deleteUser(String userId) {
        User user = findUserById(userId);
        if (user.getRole() == Role.SUPER_ADMIN) {
            throw new BusinessRuleException("Cannot delete a SUPER_ADMIN", 403);
        }
        userRepository.delete(user);
    }

    private void validateSelfRegistration(Role role) {
        if (role == Role.ADMIN || role == Role.SUPER_ADMIN) {
            throw new BusinessRuleException("Self-registration as " + role + " is not allowed", 403);
        }
    }

    private User buildAndSaveUser(String name, String email, String password,
                                  Role role, String phone, String location) {
        String normalizedEmail = email.toLowerCase().trim();
        if (userRepository.existsByEmail(normalizedEmail)) {
            throw new EntityConflictException("An account with email " + normalizedEmail + " already exists");
        }
        User user = User.builder()
                .name(name.trim())
                .email(normalizedEmail)
                .password(passwordEncoder.encode(password))
                .role(role)
                .phone(phone)
                .location(location)
                .isActive(true)
                .build();
        return userRepository.save(user);
    }

    private String issueToken(User user) {
        return jwtUtils.generateToken(user.getEmail(), Map.of("role", user.getRole().name()));
    }

    private AuthResponseRecord buildAuthResponse(String token, User user) {
        return new AuthResponseRecord(
                token,
                TOKEN_TYPE,
                user.getId(),
                user.getEmail(),
                user.getRole(),
                user.getName()
        );
    }

    private User findUserById(String userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));
    }
}