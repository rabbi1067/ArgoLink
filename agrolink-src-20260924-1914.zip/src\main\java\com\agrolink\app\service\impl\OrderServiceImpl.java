package com.agrolink.app.service.impl;

import com.agrolink.app.config.CacheConfig;
import com.agrolink.app.dto.AcceptOfferRecord;
import com.agrolink.app.dto.OrderResponseRecord;
import com.agrolink.app.exception.BusinessRuleException;
import com.agrolink.app.exception.ResourceNotFoundException;
import com.agrolink.app.model.ListingStatus;
import com.agrolink.app.model.Offer;
import com.agrolink.app.model.OfferStatus;
import com.agrolink.app.model.Order;
import com.agrolink.app.model.OrderStatus;
import com.agrolink.app.model.ProduceListing;
import com.agrolink.app.repository.OfferRepository;
import com.agrolink.app.repository.OrderRepository;
import com.agrolink.app.repository.ProduceListingRepository;
import com.agrolink.app.service.InvoiceService;
import com.agrolink.app.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private static final BigDecimal PRICE_SCALE = new BigDecimal("0.01");

    private static final Map<OrderStatus, Set<OrderStatus>> TRANSITIONS = buildTransitions();

    private final OrderRepository orderRepository;
    private final OfferRepository offerRepository;
    private final ProduceListingRepository produceListingRepository;
    private final MongoTemplate mongoTemplate;
    private final InvoiceService invoiceService;

    @Override
    @CacheEvict(cacheNames = {CacheConfig.CACHE_PUBLIC_LISTINGS, CacheConfig.CACHE_DASHBOARD_STATS}, allEntries = true)
    public OrderResponseRecord acceptOffer(String userId, AcceptOfferRecord request) {
        Offer offer = offerRepository.findById(request.offerId())
                .orElseThrow(() -> new ResourceNotFoundException("Offer", "id", request.offerId()));

        boolean involved = offer.getBuyerId().equals(userId) || offer.getFarmerId().equals(userId);
        if (!involved) {
            throw new BusinessRuleException("You are not a party to this offer", 403);
        }
        if (offer.getStatus() != OfferStatus.OFFERED) {
            throw new BusinessRuleException("Offer is no longer valid (status: " + offer.getStatus() + ")", 409);
        }

        ProduceListing listing = produceListingRepository.findById(offer.getListingId())
                .orElseThrow(() -> new ResourceNotFoundException("ProduceListing", "id", offer.getListingId()));

        ProduceListing reserved = atomicallyReserveQuantity(listing.getId(), offer.getOfferedQuantity());

        offer.setStatus(OfferStatus.ACCEPTED);
        offerRepository.save(offer);
        rejectCompetingOffers(listing.getId(), offer.getId());

        Order order = Order.builder()
                .offerId(offer.getId())
                .buyerId(offer.getBuyerId())
                .farmerId(offer.getFarmerId())
                .cropName(reserved.getCropName())
                .agreedQuantity(offer.getOfferedQuantity())
                .agreedPricePerUnit(offer.getOfferedPrice())
                .totalAmount(offer.getOfferedQuantity()
                        .multiply(offer.getOfferedPrice())
                        .setScale(PRICE_SCALE.scale(), RoundingMode.HALF_UP))
                .orderStatus(OrderStatus.PENDING)
                .deliveryAddress(request.deliveryAddress())
                .build();

        Order saved = orderRepository.save(order);
        invoiceService.syncForOrder(saved);
        return OrderResponseRecord.from(saved);
    }

    @Override
    public OrderResponseRecord getOrderById(String orderId, String userId, boolean isAdmin) {
        Order order = findOrder(orderId);
        if (!isAdmin && !order.getBuyerId().equals(userId) && !order.getFarmerId().equals(userId)) {
            throw new BusinessRuleException("You are not allowed to view this order", 403);
        }
        return OrderResponseRecord.from(order);
    }

    @Override
    public List<OrderResponseRecord> getBuyerOrders(String buyerId) {
        return orderRepository.findByBuyerId(buyerId).stream().map(OrderResponseRecord::from).toList();
    }

    @Override
    public List<OrderResponseRecord> getFarmerOrders(String farmerId) {
        return orderRepository.findByFarmerId(farmerId).stream().map(OrderResponseRecord::from).toList();
    }

    @Override
    public List<OrderResponseRecord> getOrdersByStatus(OrderStatus status) {
        return orderRepository.findByOrderStatus(status).stream().map(OrderResponseRecord::from).toList();
    }

    @Override
    @CacheEvict(cacheNames = CacheConfig.CACHE_DASHBOARD_STATS, allEntries = true)
    public OrderResponseRecord updateOrderStatus(String orderId, String userId, boolean isAdmin, OrderStatus newStatus) {
        Order order = findOrder(orderId);
        if (!isAdmin && !order.getBuyerId().equals(userId) && !order.getFarmerId().equals(userId)) {
            throw new BusinessRuleException("You are not allowed to update this order", 403);
        }
        Set<OrderStatus> allowed = TRANSITIONS.get(order.getOrderStatus());
        if (allowed == null || !allowed.contains(newStatus)) {
            throw new BusinessRuleException(
                    "Cannot transition order from " + order.getOrderStatus() + " to " + newStatus, 409);
        }
        order.setOrderStatus(newStatus);
        Order saved = orderRepository.save(order);
        invoiceService.syncForOrder(saved);
        return OrderResponseRecord.from(saved);
    }

    private ProduceListing atomicallyReserveQuantity(String listingId, BigDecimal quantity) {
        Query query = new Query(Criteria.where("_id").is(listingId)
                .and("status").in(ListingStatus.ACTIVE, ListingStatus.RESERVED)
                .and("availableQuantity").gte(quantity));
        Update update = new Update()
                .inc("availableQuantity", quantity.negate())
                .inc("reservedQuantity", quantity);

        // Atomic find-and-modify: succeeds only if availableQuantity >= quantity at update time.
        ProduceListing updated = mongoTemplate.findAndModify(query, update, ProduceListing.class);
        if (updated == null) {
            throw new BusinessRuleException("Insufficient stock or the listing is no longer available", 409);
        }
        return updated;
    }

    private void rejectCompetingOffers(String listingId, String acceptedOfferId) {
        offerRepository.findByListingIdAndStatus(listingId, OfferStatus.OFFERED)
                .stream()
                .filter(other -> !other.getId().equals(acceptedOfferId))
                .forEach(other -> {
                    other.setStatus(OfferStatus.REJECTED);
                    offerRepository.save(other);
                });
    }

    private Order findOrder(String orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", orderId));
    }

    private static Map<OrderStatus, Set<OrderStatus>> buildTransitions() {
        Map<OrderStatus, Set<OrderStatus>> transitions = new EnumMap<>(OrderStatus.class);
        transitions.put(OrderStatus.PENDING, Set.of(OrderStatus.CONFIRMED, OrderStatus.CANCELLED, OrderStatus.DISPUTED));
        transitions.put(OrderStatus.CONFIRMED, Set.of(OrderStatus.IN_TRANSIT, OrderStatus.CANCELLED, OrderStatus.DISPUTED));
        transitions.put(OrderStatus.IN_TRANSIT, Set.of(OrderStatus.DELIVERED, OrderStatus.DISPUTED));
        transitions.put(OrderStatus.DELIVERED, Set.of(OrderStatus.DISPUTED));
        return transitions;
    }
}