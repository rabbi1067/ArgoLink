package com.agrolink.app.model;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "users")
public class User {

    @Id
    private String id;

    @NotBlank(message = "Name is required")
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    private String name;

    @NotBlank(message = "Email is required")
    @Email(message = "Email must be valid")
    @Indexed(unique = true)
    private String email;

    @NotBlank(message = "Password is required")
    private String password;

    private Role role;

    @Size(max = 20, message = "Phone number is too long")
    private String phone;

    private String location;

    /** Legacy permanent URL (no longer written since signed-URL delivery). Kept for old documents. */
    private String profileImageUrl;

    /** Cloudinary public id of the avatar; the only persisted image handle. */
    private String profileImagePublicId;

    /** Cloudinary file format (extension) of the avatar, e.g. {@code png}; kept to rebuild signed URLs. */
    private String profileImageFormat;

    @Indexed
    private String createdById;

    @Indexed
    private boolean isActive = true;

    @CreatedDate
    private Instant createdAt;
}