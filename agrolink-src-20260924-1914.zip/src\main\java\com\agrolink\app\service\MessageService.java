package com.agrolink.app.service;

import com.agrolink.app.dto.ConversationDTO;
import com.agrolink.app.dto.MessageDTO;

import java.util.List;

public interface MessageService {

    ConversationDTO openByOrder(String userId, String orderId);

    ConversationDTO openByListing(String userId, String listingId);

    List<ConversationDTO> listForUser(String userId);

    List<MessageDTO> listMessages(String userId, String conversationId);

    MessageDTO sendMessage(String userId, String conversationId, String body);

    MessageDTO sendMessageWs(String senderId, String conversationId, String body);
}