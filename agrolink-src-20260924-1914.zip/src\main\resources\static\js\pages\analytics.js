window.Pages = window.Pages || {};

window.Pages.analytics = {
    container: null,
    charts: {},
    _chartPromise: null,
    _themeHandler: null,

    init(container) {
        this.container = container;
        this.destroyCharts();
        this.bindTheme();

        const user = window.Api && Api.getUser ? Api.getUser() : null;
        if (!user || (user.role !== "ADMIN" && user.role !== "SUPER_ADMIN")) {
            this.showEmpty("Insights are available to administrators only.");
            return;
        }

        this.bindRefresh();
        this.loadOverview();

        this.ensureChartJs()
            .then(() => this.loadCharts())
            .catch(() => {
                this.showEmpty("Could not load the charting library. Check your connection.");
            });
    },

    bindRefresh() {
        const button = this.container.querySelector("[data-analytics-refresh]");
        if (button) button.addEventListener("click", () => this.refresh());
    },

    refresh() {
        this.destroyCharts();
        this.loadOverview();
        this.ensureChartJs()
            .then(() => this.loadCharts())
            .catch(() => {});
    },

    bindTheme() {
        if (this._themeHandler) {
            document.removeEventListener("themechange", this._themeHandler);
        }
        this._themeHandler = () => this.applyTheme();
        document.addEventListener("themechange", this._themeHandler);
    },

    ensureChartJs() {
        if (window.Chart) return Promise.resolve();
        if (this._chartPromise) return this._chartPromise;

        this._chartPromise = new Promise((resolve, reject) => {
            const script = document.createElement("script");
            script.src = "https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js";
            script.async = true;
            script.onload = () => resolve();
            script.onerror = () => {
                this._chartPromise = null;
                reject(new Error("Chart.js failed to load"));
            };
            document.head.appendChild(script);
        });

        return this._chartPromise;
    },

    async loadOverview() {
        try {
            const res = await Api.get("/analytics/overview");
            const d = res.data || {};
            this.setValue("#analyticsListings", this.number(d.totalListings));
            this.setValue("#analyticsActive", this.number(d.activeListings));
            this.setValue("#analyticsUsers", this.number(d.totalUsers));
            this.setValue("#analyticsOrders", this.number(d.totalOrders));
        } catch (error) {
            if (window.Toast) Toast.fromResponse(error, "Could not load analytics overview");
        }
    },

    async loadCharts() {
        try {
            const [supplyDemandRes, revenueRes, cropRes] = await Promise.all([
                Api.get("/analytics/supply-demand"),
                Api.get("/analytics/revenue", { months: 6 }),
                Api.get("/analytics/crop-distribution"),
            ]);

            this.renderSupplyDemand(supplyDemandRes.data);
            this.renderVolume(revenueRes.data);
            this.renderCropDistribution(cropRes.data);
        } catch (error) {
            this.showEmpty("Could not load analytics data");
            if (window.Toast) Toast.fromResponse(error, "Could not load analytics data");
        }
    },

    renderSupplyDemand(data) {
        const canvas = this.ensureCanvas("supplyDemandWrap", "supplyDemandChart", "Supply versus demand bar chart");
        if (!canvas) return;
        if (!data || !data.labels || !data.labels.length) {
            this.showEmptyIn("supplyDemandWrap", "No supply or demand data yet.");
            return;
        }

        const palette = this.palette();
        this.charts.supplyDemand = new Chart(canvas, {
            type: "bar",
            data: {
                labels: data.labels,
                datasets: [
                    {
                        label: "Supply",
                        data: data.supply,
                        backgroundColor: palette.brandSoft,
                        borderColor: palette.brand,
                        borderWidth: 1,
                    },
                    {
                        label: "Demand",
                        data: data.demand,
                        backgroundColor: palette.accentSoft,
                        borderColor: palette.accent,
                        borderWidth: 1,
                    },
                ],
            },
            options: this.baseOptions(palette),
        });
    },

    renderVolume(data) {
        const canvas = this.ensureCanvas("volumeWrap", "volumeChart", "Monthly traded volume line chart");
        if (!canvas) return;
        if (!data || !data.labels || !data.labels.length) {
            this.showEmptyIn("volumeWrap", "No traded volume yet.");
            return;
        }

        const palette = this.palette();
        this.charts.volume = new Chart(canvas, {
            type: "line",
            data: {
                labels: data.labels.map((label) => this.monthLabel(label)),
                datasets: [
                    {
                        label: "Traded Volume (BDT)",
                        data: data.data,
                        borderColor: palette.brand,
                        backgroundColor: palette.brandSoft,
                        fill: true,
                        tension: 0.35,
                        pointBackgroundColor: palette.brand,
                        pointRadius: 4,
                    },
                ],
            },
            options: this.baseOptions(palette, {
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: (context) => ` ${this.currency(context.parsed.y)}`,
                        },
                    },
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: palette.muted,
                            callback: (value) => this.compactCurrency(value),
                        },
                        grid: { color: palette.grid },
                    },
                },
            }),
        });
    },

    renderCropDistribution(data) {
        const canvas = this.ensureCanvas("cropDistributionWrap", "cropDistributionChart", "Crop distribution donut chart");
        if (!canvas) return;
        if (!data || !data.length) {
            this.showEmptyIn("cropDistributionWrap", "No crop distribution data yet.");
            return;
        }

        const palette = this.palette();
        const colors = this.donutColors();
        this.charts.cropDistribution = new Chart(canvas, {
            type: "doughnut",
            data: {
                labels: data.map((item) => item.cropName),
                datasets: [
                    {
                        data: data.map((item) => item.count),
                        backgroundColor: colors,
                        borderColor: palette.surface,
                        borderWidth: 2,
                    },
                ],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: "bottom",
                        labels: { color: palette.text },
                    },
                    tooltip: {
                        callbacks: {
                            label: (context) =>
                                ` ${context.label}: ${this.number(context.parsed)} orders`,
                        },
                    },
                },
            },
        });
    },

    applyTheme() {
        const palette = this.palette();
        Object.values(this.charts).forEach((chart) => {
            if (!chart || typeof chart.update !== "function") return;
            if (chart.options) {
                chart.options.plugins.legend.labels.color = palette.text;
                if (chart.options.plugins.tooltip) {
                    chart.options.plugins.tooltip.titleColor = palette.text;
                    chart.options.plugins.tooltip.bodyColor = palette.text;
                }
                if (chart.options.scales && chart.options.scales.x) {
                    chart.options.scales.x.ticks.color = palette.muted;
                    chart.options.scales.x.grid.color = palette.grid;
                }
                if (chart.options.scales && chart.options.scales.y) {
                    chart.options.scales.y.ticks.color = palette.muted;
                    chart.options.scales.y.grid.color = palette.grid;
                }
            }
            chart.update();
        });
    },

    baseOptions(palette, extra) {
        const options = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: palette.text },
                },
                tooltip: {
                    backgroundColor: palette.surface,
                    titleColor: palette.text,
                    bodyColor: palette.text,
                    borderColor: palette.grid,
                    borderWidth: 1,
                },
            },
            scales: {
                x: {
                    ticks: { color: palette.muted },
                    grid: { color: palette.grid },
                },
                y: {
                    beginAtZero: true,
                    ticks: { color: palette.muted },
                    grid: { color: palette.grid },
                },
            },
        };

        if (!extra) return options;
        if (extra.plugins) {
            options.plugins = Object.assign({}, options.plugins, extra.plugins);
        }
        if (extra.scales) {
            options.scales = Object.assign({}, options.scales, extra.scales);
        }
        return options;
    },

    palette() {
        const css = getComputedStyle(document.documentElement);
        const read = (name, fallback) => {
            const value = css.getPropertyValue(name).trim();
            return value || fallback;
        };
        const brand = read("--color-brand-600", "#059669");
        const accent = read("--color-info", "#2563eb");
        return {
            text: read("--color-text", "#0f172a"),
            muted: read("--color-text-muted", "#64748b"),
            grid: read("--color-border", "#e2e8f0"),
            surface: read("--color-surface", "#ffffff"),
            brand,
            accent,
            brandSoft: this.alpha(brand, 0.18),
            accentSoft: this.alpha(accent, 0.18),
        };
    },

    alpha(hex, opacity) {
        const clean = String(hex || "").replace("#", "");
        let red, green, blue;
        if (clean.length === 3) {
            red = parseInt(clean[0] + clean[0], 16);
            green = parseInt(clean[1] + clean[1], 16);
            blue = parseInt(clean[2] + clean[2], 16);
        } else if (clean.length === 6) {
            red = parseInt(clean.slice(0, 2), 16);
            green = parseInt(clean.slice(2, 4), 16);
            blue = parseInt(clean.slice(4, 6), 16);
        } else {
            return hex;
        }
        if ([red, green, blue].some((channel) => Number.isNaN(channel))) return hex;
        return `rgba(${red}, ${green}, ${blue}, ${opacity})`;
    },

    donutColors() {
        return [
            "#059669", "#10b981", "#f59e0b", "#3b82f6", "#8b5cf6",
            "#ef4444", "#ec4899", "#14b8a6", "#f97316", "#06b6d4",
            "#84cc16", "#a855f7",
        ];
    },

    ensureCanvas(wrapId, canvasId, ariaLabel) {
        let wrap = this.container.querySelector(`#${wrapId}`);
        if (!wrap) return null;

        let canvas = this.container.querySelector(`#${canvasId}`);
        if (!canvas) {
            wrap.innerHTML = `<canvas id="${canvasId}" aria-label="${ariaLabel}" role="img"></canvas>`;
            canvas = this.container.querySelector(`#${canvasId}`);
        }
        return canvas;
    },

    showEmpty(message) {
        const overview = this.container.querySelector("#analyticsOverview");
        if (overview) {
            overview.innerHTML = `<div class="empty-state md:col-span-4">${this.esc(message)}</div>`;
        }
    },

    showEmptyIn(wrapId, message) {
        const wrap = this.container.querySelector(`#${wrapId}`);
        if (wrap) wrap.innerHTML = `<div class="empty-state">${this.esc(message)}</div>`;
    },

    destroyCharts() {
        Object.values(this.charts).forEach((chart) => {
            if (chart && typeof chart.destroy === "function") chart.destroy();
        });
        this.charts = {};
    },

    setValue(selector, value) {
        const el = this.container.querySelector(selector);
        if (el) el.textContent = value;
    },

    monthLabel(value) {
        const match = /^(\d{4})-(\d{2})$/.exec(String(value || ""));
        if (!match) return String(value);
        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        const month = monthNames[Number(match[2]) - 1];
        return month ? `${month} ${match[1]}` : String(value);
    },

    number(value) {
        return Number(value || 0).toLocaleString("en-IN");
    },

    currency(value) {
        return `BDT ${Number(value || 0).toLocaleString("en-IN", { maximumFractionDigits: 0 })}`;
    },

    compactCurrency(value) {
        const amount = Number(value || 0);
        if (amount >= 1000000) return `${(amount / 1000000).toFixed(1)}M`;
        if (amount >= 1000) return `${(amount / 1000).toFixed(1)}K`;
        return String(amount);
    },

    esc(value) {
        return String(value)
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    },
};