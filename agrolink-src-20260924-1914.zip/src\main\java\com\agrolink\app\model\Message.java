package com.agrolink.app.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

/**
 * A single message inside a {@link Conversation}. Only the two thread
 * participants may send/read; `readByBuyer` / `readByFarmer` support the
 * unread badge without extra aggregate queries. Messages are immutable once
 * sent (withdraw/hide is a viewer-side concern, not an edit).
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "messages")
@CompoundIndex(name = "messages_conv_created", def = "{'conversationId': 1, 'createdAt': 1}")
public class Message {

    @Id
    private String id;

    @Indexed
    private String conversationId;

    @Indexed
    private String senderId;

    private String senderRole;

    private String body;

    private boolean readByBuyer;

    private boolean readByFarmer;

    @CreatedDate
    private Instant createdAt;
}
