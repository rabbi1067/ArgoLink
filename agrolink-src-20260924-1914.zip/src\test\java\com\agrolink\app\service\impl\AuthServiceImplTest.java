package com.agrolink.app.service.impl;

import com.agrolink.app.dto.AuthResponseRecord;
import com.agrolink.app.dto.RegisterRequestRecord;
import com.agrolink.app.exception.BusinessRuleException;
import com.agrolink.app.exception.EntityConflictException;
import com.agrolink.app.model.Role;
import com.agrolink.app.model.User;
import com.agrolink.app.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthServiceImplTest {

    @Mock
    private UserRepository userRepository;
    @Mock
    private PasswordEncoder passwordEncoder;
    @Mock
    private AuthenticationManager authenticationManager;
    @Mock
    private com.agrolink.app.service.JwtUtils jwtUtils;

    private AuthServiceImpl authService;

    @BeforeEach
    void setUp() {
        authService = new AuthServiceImpl(userRepository, passwordEncoder, authenticationManager, jwtUtils);
    }

    @Test
    void register_shouldEncodePasswordAndReturnToken() {
        when(userRepository.existsByEmail("farmer@agrolink.com")).thenReturn(false);
        when(passwordEncoder.encode("password123")).thenReturn("$2a$12$encoded");
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(jwtUtils.generateToken(anyString(), anyMap())).thenReturn("jwt-token");

        RegisterRequestRecord request = new RegisterRequestRecord(
                "Green Valley Farms", "farmer@agrolink.com", "password123",
                Role.FARMER, "+1-555-0100", "Nairobi");

        AuthResponseRecord response = authService.register(request);

        assertNotNull(response);
        assertEquals("jwt-token", response.token());
        assertEquals("Bearer", response.type());
        assertEquals("farmer@agrolink.com", response.email());
        assertEquals(Role.FARMER, response.role());
        assertEquals("Green Valley Farms", response.name());
        verify(passwordEncoder).encode("password123");
        verify(userRepository).save(any(User.class));
    }

    @Test
    void register_shouldRejectDuplicateEmail() {
        when(userRepository.existsByEmail("farmer@agrolink.com")).thenReturn(true);
        RegisterRequestRecord request = new RegisterRequestRecord(
                "Green Valley Farms", "farmer@agrolink.com", "password123",
                Role.FARMER, null, null);

        assertThrows(EntityConflictException.class, () -> authService.register(request));

        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    void register_shouldRejectSelfRegistrationAsAdmin() {
        RegisterRequestRecord request = new RegisterRequestRecord(
                "Admin Wannabe", "admin@agrolink.com", "password123",
                Role.ADMIN, null, null);

        assertThrows(BusinessRuleException.class, () -> authService.register(request));
    }
}