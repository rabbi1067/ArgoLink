package com.agrolink.app.service;

/**
 * Abstraction over the Cloudinary CDN used for all AgroLink image assets
 * (profile avatars, produce pictures, QR codes).
 *
 * <p>Security contract:</p>
 * <ul>
 *   <li>Assets are uploaded with {@code delivery type=authenticated} — Cloudinary
 *       refuses to deliver them without a valid signed delivery URL.</li>
 *   <li>MongoDB stores only the {@code publicId} — never a permanent public URL,
 *       never raw binaries or base64.</li>
 *   <li>Consumers always request a signed delivery URL from the backend
 *       ({@link #signedUrl(String, String)}), and only the server can mint new ones.</li>
 * </ul>
 *
* <p>Expiring token-based URLs ({@code __cld_token__}) require a Cloudinary
 * Advanced plan plus a custom delivery hostname and an account-level encryption
 * key, so delivery relies on signed URLs of the form {@code s--...--} instead.
 * The signature has no time-to-live of its own; links stay usable until your app
 * decides to stop serving them, so treat them as private.</p>
 */
public interface CloudinaryService {

    /** Metadata returned by an upload; only {@code publicId} and {@code format} are persisted. */
    record UploadResult(String publicId, String secureUrl, String format) {
    }

    /**
     * Validates and uploads an image (authenticated delivery type) to the given folder.
     *
     * @param content     raw image bytes
     * @param contentType declared MIME type (must be {@code image/*})
     * @param folder      destination folder, e.g. {@code agrolink/produce}
     * @return the upload result (publicId + one-time secureUrl; persist only publicId)
     */
    UploadResult uploadImage(byte[] content, String contentType, String folder);

    /**
     * Uploads a profile avatar to the configured avatar folder.
     */
    UploadResult uploadAvatar(byte[] content, String contentType);

    /**
     * Uploads a produce listing picture to the configured produce folder.
     */
    UploadResult uploadProduceImage(byte[] content, String contentType);

    /**
     * Builds a signed delivery URL ({@code s--...--}) for an authenticated asset.
     *
     * @param publicId the persisted Cloudinary public id (without file extension),
     *                 e.g. {@code agrolink/produce/abc123}
     * @param format   the asset file format/extension, e.g. {@code png} or {@code jpg}
     * @return a full {@code res.cloudinary.com} delivery URL with a signature
     *         component, or {@code null} when the public id is blank
     */
    String signedUrl(String publicId, String format);
}