window.Pages = window.Pages || {};

window.Pages.users = {
    container: null,
    isAdmin: false,
    users: [],

    ROLE_CLASS: {
        FARMER: "badge-success",
        BUYER: "badge-info",
        ADMIN: "badge-warning",
        SUPER_ADMIN: "badge-error",
    },

    init(container) {
        this.container = container;
        const user = window.Api && Api.getUser ? Api.getUser() : null;
        this.isAdmin = user && (user.role === "ADMIN" || user.role === "SUPER_ADMIN");

        if (!this.isAdmin) {
            const wrap = this.container.querySelector("#usersTableWrap");
            if (wrap) wrap.innerHTML = '<div class="empty-state">Admins only.</div>';
            const addButton = this.container.querySelector("#usersAddBtn");
            if (addButton) addButton.hidden = true;
            return;
        }

        this.bindControls();
        this.load();
    },

    async load() {
        const wrap = this.container.querySelector("#usersTableWrap");
        const filter = this.container.querySelector("#userRoleFilter");
        const role = filter ? filter.value : "";

        try {
            const res = role
                ? await Api.get(`/users/by-role/${role}`)
                : await Api.get("/users");
            this.users = res.data || [];
            this.render();
        } catch (error) {
            wrap.innerHTML = '<div class="empty-state">Could not load users</div>';
            if (window.Toast) Toast.fromResponse(error, "Could not load users");
        }
    },

    bindControls() {
        const addButton = this.container.querySelector("#usersAddBtn");
        if (addButton) addButton.addEventListener("click", () => this.openCreateModal());

        const refresh = this.container.querySelector("[data-users-refresh]");
        if (refresh) refresh.addEventListener("click", () => this.load());

        const filter = this.container.querySelector("#userRoleFilter");
        if (filter) filter.addEventListener("change", () => this.load());

        const search = this.container.querySelector("#usersSearch");
        if (search) search.addEventListener("input", () => this.render());

        const modal = this.container.querySelector("#userModal");
        const modalClose = this.container.querySelector("[data-user-modal-close]");
        if (modalClose) modalClose.addEventListener("click", () => this.closeModal(modal));
        if (modal) {
            modal.addEventListener("click", (event) => {
                if (event.target === modal) this.closeModal(modal);
            });
        }

        const form = this.container.querySelector("#userForm");
        if (form) form.addEventListener("submit", (event) => this.handleCreateSubmit(event));

        const wrap = this.container.querySelector("#usersTableWrap");
        if (wrap) wrap.addEventListener("click", (event) => this.handleTableClick(event));

        this.state = this.state || {};
        this.state.escHandler = (event) => {
            if (event.key !== "Escape") return;
            const open = this.container.querySelector(".modal-backdrop.open");
            if (open) this.closeModal(open);
        };
        document.addEventListener("keydown", this.state.escHandler);
    },

    handleTableClick(event) {
        const button = event.target.closest("[data-user-toggle]");
        if (!button) return;

        const id = button.dataset.id;
        const active = button.dataset.active === "true";
        const actionText = active ? "deactivate" : "activate";

        if (!window.confirm(`Do you want to ${actionText} this user?`)) return;

        Api.patch(`/users/${id}/status`, { active: !active })
            .then(() => {
                if (window.Toast) Toast.success(`User ${actionText}d`);
                this.load();
            })
            .catch((error) => {
                if (window.Toast) Toast.fromResponse(error, `Could not ${actionText} user`);
            });
    },

    render() {
        const wrap = this.container.querySelector("#usersTableWrap");
        const count = this.container.querySelector("#usersCount");
        const search = this.container.querySelector("#usersSearch");
        if (!wrap) return;

        const term = (search ? search.value : "").trim().toLowerCase();
        const filtered = this.users.filter((user) => {
            if (!term) return true;
            return `${user.name || ""} ${user.email || ""}`.toLowerCase().includes(term);
        });

        if (count) count.textContent = String(filtered.length);
        if (!filtered.length) {
            wrap.innerHTML = '<div class="empty-state">No users found.</div>';
            return;
        }

        const rows = filtered
            .map((user) => {
                const initials = (user.name || "?")
                    .split(" ")
                    .map((part) => part[0])
                    .filter(Boolean)
                    .slice(0, 2)
                    .join("")
                    .toUpperCase();
                const roleClass = this.ROLE_CLASS[user.role] || "badge-info";

                return `
                    <tr>
                        <td>
                            <div class="flex items-center gap-3">
                                <span class="avatar">${this.esc(initials)}</span>
                                <div>
                                    <p class="mb-0 font-semibold" style="font-weight: 600;">${this.esc(user.name || "—")}</p>
                                </div>
                            </div>
                        </td>
                        <td><span class="font-mono" style="font-size: 0.8rem;">${this.esc(user.email || "—")}</span></td>
                        <td><span class="badge ${roleClass}">${this.esc(user.role || "")}</span></td>
                        <td>${this.esc(user.phone || "—")}</td>
                        <td>${this.esc(user.location || "—")}</td>
                        <td>
                            ${user.active === false
                                ? '<span class="badge badge-error">Inactive</span>'
                                : '<span class="badge badge-success">Active</span>'}
                        </td>
                        <td>
                            <button type="button" class="btn btn-sm ${user.active === false ? "btn-primary" : "btn-danger"}" data-user-toggle data-id="${this.esc(user.id)}" data-active="${user.active === false ? "false" : "true"}">
                                ${user.active === false ? "Activate" : "Deactivate"}
                            </button>
                        </td>
                    </tr>`;
            })
            .join("");

        wrap.innerHTML = `
            <div class="table-scroll">
                <table class="table">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Phone</th>
                            <th>Location</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>`;
    },

    openCreateModal() {
        const modal = this.container.querySelector("#userModal");
        const form = this.container.querySelector("#userForm");
        if (form) form.reset();
        this.populateRoles();
        if (modal) this.openModal(modal);
    },

    populateRoles() {
        const roleSelect = this.container.querySelector("#userRole");
        if (!roleSelect) return;
        const current = roleSelect.value;
        const isSuper = this.currentUserRole() === "SUPER_ADMIN";
        roleSelect.innerHTML =
            '<option value="">Select role</option>' +
            '<option value="FARMER">Farmer</option>' +
            '<option value="BUYER">Buyer</option>' +
            '<option value="ADMIN">Admin</option>' +
            (isSuper ? '<option value="SUPER_ADMIN">Super Admin</option>' : "");
        roleSelect.value = current;
    },

    currentUserRole() {
        const user = window.Api && Api.getUser ? Api.getUser() : null;
        return user && user.role ? user.role : "";
    },

    async handleCreateSubmit(event) {
        const form = this.container.querySelector("#userForm");
        if (!form) return;
        event.preventDefault();

        const role = this.value("#userRole");
        const body = {
            name: this.value("#userName"),
            email: this.value("#userEmail"),
            password: this.value("#userPassword"),
            role,
            phone: this.value("#userPhone") || null,
            location: this.value("#userLocation") || null,
        };

        if (!body.name || !body.email || body.password.length < 8) {
            if (window.Toast) Toast.error("Fill all required fields");
            return;
        }

        const submit = form.querySelector("button[type='submit']");
        const original = submit ? submit.textContent : "";
        if (submit) {
            submit.disabled = true;
            submit.textContent = "Creating...";
        }

        try {
            await Api.post("/users", body);
            if (window.Toast) Toast.success("User created");
            this.closeModal(this.container.querySelector("#userModal"));
            this.load();
        } catch (error) {
            if (window.Toast) Toast.fromResponse(error, "Could not create user");
        } finally {
            if (submit) {
                submit.disabled = false;
                submit.textContent = original;
            }
        }
    },

    openModal(modal) {
        if (!modal) return;
        modal.classList.add("open");
        modal.setAttribute("aria-hidden", "false");
    },

    closeModal(modal) {
        if (!modal) return;
        modal.classList.remove("open");
        modal.setAttribute("aria-hidden", "true");
    },

    value(selector) {
        const el = this.container.querySelector(selector);
        return el ? el.value : "";
    },

    esc(value) {
        return String(value)
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    },
};