package com.agrolink.app.dto;

/**
 * Response for image-upload endpoints. The client persists the {@code publicId}
 * and {@code format} and may display the signed {@code imageUrl} immediately.
 */
public record ImageUploadResponse(String publicId, String format, String imageUrl) {
}