package com.agrolink.app.service;

import com.agrolink.app.dto.AuthResponseRecord;
import com.agrolink.app.dto.CreateUserRecord;
import com.agrolink.app.dto.LoginRequestRecord;
import com.agrolink.app.dto.RegisterRequestRecord;
import com.agrolink.app.model.Role;
import com.agrolink.app.model.User;

import java.util.List;

public interface AuthService {

    AuthResponseRecord register(RegisterRequestRecord request);

    AuthResponseRecord login(LoginRequestRecord request);

    AuthResponseRecord createUser(CreateUserRecord request);

    List<User> getAllUsers();

    List<User> getUsersByRole(Role role);

    User findByEmail(String email);

    User updateUserRole(String userId, Role role);

    void deleteUser(String userId);
}