package com.agrolink.app.controller.api;

import com.agrolink.app.dto.AcceptOfferRecord;
import com.agrolink.app.dto.ApiResponse;
import com.agrolink.app.dto.OrderResponseRecord;
import com.agrolink.app.dto.UpdateOrderStatusRecord;
import com.agrolink.app.model.OrderStatus;
import com.agrolink.app.model.Role;
import com.agrolink.app.model.User;
import com.agrolink.app.service.OrderService;
import com.agrolink.app.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;
    private final UserService userService;

    @PostMapping
    @PreAuthorize("hasAnyRole('BUYER', 'FARMER', 'ADMIN', 'SUPER_ADMIN')")
    public ResponseEntity<ApiResponse<OrderResponseRecord>> acceptOffer(
            @Valid @RequestBody AcceptOfferRecord request,
            Authentication authentication) {
        OrderResponseRecord order = orderService.acceptOffer(currentUser(authentication).getId(), request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Order created", order));
    }

    @GetMapping("/{orderId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<OrderResponseRecord>> getOrder(@PathVariable String orderId,
                                                                     Authentication authentication) {
        User user = currentUser(authentication);
        return ResponseEntity.ok(ApiResponse.ok(
                orderService.getOrderById(orderId, user.getId(), isAdmin(user))));
    }

    @GetMapping("/my")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<OrderResponseRecord>>> myOrders(
            @RequestParam(defaultValue = "BUYER") String as,
            Authentication authentication) {
        User user = currentUser(authentication);
        List<OrderResponseRecord> orders = as.equalsIgnoreCase("FARMER")
                ? orderService.getFarmerOrders(user.getId())
                : orderService.getBuyerOrders(user.getId());
        return ResponseEntity.ok(ApiResponse.ok(orders));
    }

    @PatchMapping("/{orderId}/status")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<OrderResponseRecord>> updateStatus(
            @PathVariable String orderId,
            @Valid @RequestBody UpdateOrderStatusRecord request,
            Authentication authentication) {
        User user = currentUser(authentication);
        return ResponseEntity.ok(ApiResponse.ok("Order status updated",
                orderService.updateOrderStatus(orderId, user.getId(), isAdmin(user), request.status())));
    }

    @GetMapping("/status/{status}")
    @PreAuthorize("hasAnyRole('ADMIN', 'SUPER_ADMIN')")
    public ResponseEntity<ApiResponse<List<OrderResponseRecord>>> ordersByStatus(
            @PathVariable OrderStatus status) {
        return ResponseEntity.ok(ApiResponse.ok(orderService.getOrdersByStatus(status)));
    }

    private User currentUser(Authentication authentication) {
        return userService.getUserByEmail(authentication.getName());
    }

    private boolean isAdmin(User user) {
        return user.getRole() == Role.ADMIN || user.getRole() == Role.SUPER_ADMIN;
    }
}