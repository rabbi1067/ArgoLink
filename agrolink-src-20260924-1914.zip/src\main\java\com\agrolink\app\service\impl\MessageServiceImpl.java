package com.agrolink.app.service.impl;

import com.agrolink.app.dto.ConversationDTO;
import com.agrolink.app.dto.MessageDTO;
import com.agrolink.app.exception.BusinessRuleException;
import com.agrolink.app.exception.ResourceNotFoundException;
import com.agrolink.app.model.Conversation;
import com.agrolink.app.model.Message;
import com.agrolink.app.model.Order;
import com.agrolink.app.model.ProduceListing;
import com.agrolink.app.model.User;
import com.agrolink.app.repository.ConversationRepository;
import com.agrolink.app.repository.MessageRepository;
import com.agrolink.app.repository.OrderRepository;
import com.agrolink.app.repository.ProduceListingRepository;
import com.agrolink.app.repository.UserRepository;
import com.agrolink.app.service.MessageService;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class MessageServiceImpl implements MessageService {

    private static final int PREVIEW_LENGTH = 60;

    private final ConversationRepository conversationRepository;
    private final MessageRepository messageRepository;
    private final OrderRepository orderRepository;
    private final ProduceListingRepository produceListingRepository;
    private final UserRepository userRepository;
    private final SimpMessagingTemplate messagingTemplate;

    @Override
    public ConversationDTO openByOrder(String userId, String orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", orderId));
        if (!order.getBuyerId().equals(userId) && !order.getFarmerId().equals(userId)) {
            throw new BusinessRuleException("You are not a party to this order", 403);
        }
        Conversation conversation = conversationRepository.findByOrderId(orderId).orElseGet(() ->
                conversationRepository.save(Conversation.builder()
                        .orderId(orderId)
                        .buyerId(order.getBuyerId())
                        .farmerId(order.getFarmerId())
                        .subject(order.getCropName() + " order")
                        .participantIds(new ArrayList<>(List.of(order.getBuyerId(), order.getFarmerId())))
                        .lastMessageAt(null)
                        .build()));
        return toDto(conversation, userId);
    }

    @Override
    public ConversationDTO openByListing(String userId, String listingId) {
        ProduceListing listing = produceListingRepository.findById(listingId)
                .orElseThrow(() -> new ResourceNotFoundException("ProduceListing", "id", listingId));
        if (listing.getFarmerId() == null || listing.getFarmerId().isBlank()) {
            throw new BusinessRuleException("Listing has no farmer to contact", 404);
        }
        Conversation conversation = conversationRepository.findByListingId(listingId).orElseGet(() ->
                conversationRepository.save(Conversation.builder()
                        .listingId(listingId)
                        .buyerId(userId)
                        .farmerId(listing.getFarmerId())
                        .subject(listing.getCropName() + " enquiry")
                        .participantIds(new ArrayList<>(List.of(userId, listing.getFarmerId())))
                        .lastMessageAt(null)
                        .build()));
        return toDto(conversation, userId);
    }

    @Override
    public List<ConversationDTO> listForUser(String userId) {
        return conversationRepository.findByParticipantIdsContainingOrderByLastMessageAtDesc(userId)
                .stream()
                .map(conversation -> toDto(conversation, userId))
                .toList();
    }

    @Override
    public List<MessageDTO> listMessages(String userId, String conversationId) {
        Conversation conversation = findConversation(conversationId);
        assertParticipant(conversation, userId);
        markRead(conversation, userId);
        return messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId)
                .stream()
                .map(this::toMessageDto)
                .toList();
    }

    @Override
    public MessageDTO sendMessage(String userId, String conversationId, String body) {
        Conversation conversation = findConversation(conversationId);
        assertParticipant(conversation, userId);
        assertNotModerated(conversation);
        return saveAndBroadcast(conversation, userId, body.trim());
    }

    @Override
    public MessageDTO sendMessageWs(String senderId, String conversationId, String body) {
        Conversation conversation = findConversation(conversationId);
        assertParticipant(conversation, senderId);
        assertNotModerated(conversation);
        return saveAndBroadcast(conversation, senderId, body.trim());
    }

    private MessageDTO saveAndBroadcast(Conversation conversation, String senderId, String body) {
        String senderRole = conversation.getBuyerId().equals(senderId) ? "BUYER" : "FARMER";
        Message message = Message.builder()
                .conversationId(conversation.getId())
                .senderId(senderId)
                .senderRole(senderRole)
                .body(body)
                .build();
        message = messageRepository.save(message);

        conversation.setLastMessageAt(Instant.now());
        conversationRepository.save(conversation);

        MessageDTO dto = toMessageDto(message);
        messagingTemplate.convertAndSend("/topic/conversation." + conversation.getId() + ".messages", dto);
        return dto;
    }

    private ConversationDTO toDto(Conversation conversation, String viewerId) {
        boolean viewerIsBuyer = conversation.getBuyerId().equals(viewerId);
        String otherPartyId = viewerIsBuyer ? conversation.getFarmerId() : conversation.getBuyerId();
        String otherPartyRole = viewerIsBuyer ? "FARMER" : "BUYER";
        String otherPartyName = userRepository.findById(otherPartyId)
                .map(User::getName)
                .orElse("Unknown user");

        List<Message> messages = messageRepository.findByConversationIdOrderByCreatedAtAsc(conversation.getId());
        long unread = messages.stream()
                .filter(message -> !message.getSenderId().equals(viewerId))
                .filter(message -> viewerIsBuyer ? !message.isReadByBuyer() : !message.isReadByFarmer())
                .count();
        String lastMessage = messages.isEmpty() ? null : preview(messages.get(messages.size() - 1).getBody());

        return new ConversationDTO(
                conversation.getId(),
                conversation.getOrderId(),
                conversation.getListingId(),
                otherPartyId,
                otherPartyName,
                otherPartyRole,
                conversation.getSubject(),
                lastMessage,
                conversation.getLastMessageAt(),
                unread,
                conversation.isModerated()
        );
    }

    private MessageDTO toMessageDto(Message message) {
        return new MessageDTO(
                message.getId(),
                message.getConversationId(),
                message.getSenderId(),
                message.getSenderRole(),
                message.getBody(),
                message.isReadByBuyer(),
                message.isReadByFarmer(),
                message.getCreatedAt()
        );
    }

    private void markRead(Conversation conversation, String viewerId) {
        boolean viewerIsBuyer = conversation.getBuyerId().equals(viewerId);
        List<Message> unread = messageRepository.findByConversationIdOrderByCreatedAtAsc(conversation.getId())
                .stream()
                .filter(message -> !message.getSenderId().equals(viewerId))
                .filter(message -> viewerIsBuyer ? !message.isReadByBuyer() : !message.isReadByFarmer())
                .toList();
        if (unread.isEmpty()) {
            return;
        }
        unread.forEach(message -> {
            if (viewerIsBuyer) {
                message.setReadByBuyer(true);
            } else {
                message.setReadByFarmer(true);
            }
        });
        messageRepository.saveAll(unread);
    }

    private Conversation findConversation(String conversationId) {
        return conversationRepository.findById(conversationId)
                .orElseThrow(() -> new ResourceNotFoundException("Conversation", "id", conversationId));
    }

    private void assertParticipant(Conversation conversation, String userId) {
        if (!conversation.getParticipantIds().contains(userId)) {
            throw new BusinessRuleException("You are not a participant of this conversation", 403);
        }
    }

    private void assertNotModerated(Conversation conversation) {
        if (conversation.isModerated()) {
            throw new BusinessRuleException("This thread is under moderation", 403);
        }
    }

    private String preview(String body) {
        if (body == null || body.isBlank()) {
            return "";
        }
        String trimmed = body.replaceAll("\\s+", " ").trim();
        return trimmed.length() <= PREVIEW_LENGTH ? trimmed : trimmed.substring(0, PREVIEW_LENGTH) + "…";
    }
}