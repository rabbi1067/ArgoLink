package com.agrolink.app.model;

public enum OrderStatus {
    PENDING,
    CONFIRMED,
    IN_TRANSIT,
    DELIVERED,
    CANCELLED,
    DISPUTED
}