package com.agrolink.app.service;

import com.agrolink.app.dto.WeatherForecastDTO;

import java.util.List;

public interface WeatherService {

    /**
     * Weather for a Bangladeshi {@code district} for the next N days (1..7).
     *
     * <p>Data is provided by <strong>Open-Meteo</strong> (free, key-less) and cached
     * per district for one hour. It is a forecast, not agronomic advice.
     *
     * @param district a valid Bangladeshi district name (case-insensitive), else
     *                 {@link com.agrolink.app.exception.ResourceNotFoundException}
     * @param days     1..7
     */
    WeatherForecastDTO getForecast(String district, int days);

    /** Same as {@link #getForecast(String, int)}; explicit "I want the cache" entry point for the assistant. */
    WeatherForecastDTO getForecastCached(String district, int days);

    /**
     * Clears the cached entry for {@code district} and fetches live data again.
     * Throttled per district (30 s) so the public endpoint cannot be used to hammer Open-Meteo;
     * inside the cooldown the current cached forecast is returned.
     */
    WeatherForecastDTO refreshForecast(String district, int days);

    /** All 64 supported Bangladeshi districts, alphabetical (dropdown source). */
    List<String> getDistricts();

    /**
     * Weather pinned to a raw device {@code lat}/{@code lon}, mapped to the nearest
     * known district. Same source, caching and fallback contract as {@link #getForecast(String, int)}.
     */
    WeatherForecastDTO getForecastByLocation(double lat, double lon, int days);
}