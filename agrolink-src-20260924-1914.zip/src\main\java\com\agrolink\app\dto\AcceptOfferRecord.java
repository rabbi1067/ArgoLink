package com.agrolink.app.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public record AcceptOfferRecord(
        @NotNull(message = "Offer id is required")
        String offerId,

        @NotBlank(message = "Delivery address is required")
        String deliveryAddress
) {
}