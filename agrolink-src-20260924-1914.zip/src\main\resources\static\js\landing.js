(function () {
    "use strict";

    const $ = (selector, root) => (root || document).querySelector(selector);
    const $$ = (selector, root) => Array.from((root || document).querySelectorAll(selector));

    const CACHE_KEY = "agrolink_crops_cache";
    const CACHE_TTL = 10 * 60 * 1000;

    const Explorer = {
        categories: [],
        listings: [],

        getCache() {
            try {
                const raw = localStorage.getItem(CACHE_KEY);
                if (!raw) return null;
                const parsed = JSON.parse(raw);
                if (!parsed || !parsed.ts || Date.now() - parsed.ts > CACHE_TTL) {
                    localStorage.removeItem(CACHE_KEY);
                    return null;
                }
                return parsed;
            } catch {
                return null;
            }
        },

        setCache(data) {
            try {
                localStorage.setItem(CACHE_KEY, JSON.stringify({ ts: Date.now(), ...data }));
            } catch {
                return;
            }
        },

        async init(force = false) {
            const cached = force ? null : this.getCache();

            if (cached) {
                this.categories = cached.categories || [];
                this.listings = cached.listings || [];
                this.refreshCategories();
                this.applyFilter();
                return;
            }

            const grid = $("#cropGrid");
            if (grid && window.Loader) {
                Loader.render(grid, Loader.skeletonCards(6));
            }

            try {
                const [categoriesRes, listingsRes] = await Promise.all([
                    Api.get("/produce/categories"),
                    Api.get("/produce/listings"),
                ]);

                this.categories = categoriesRes && categoriesRes.data ? categoriesRes.data : [];
                this.listings = listingsRes && listingsRes.data ? listingsRes.data : [];

                this.setCache({ categories: this.categories, listings: this.listings });
                this.refreshCategories();
                this.applyFilter();
            } catch (error) {
                if (window.Toast) {
                    Toast.error(error && error.message ? error.message : "Could not load produce listings");
                }
                if (grid) {
                    grid.innerHTML =
                        '<div class="empty-state">No produce available right now.<br>Please try again later.</div>';
                }
            }
        },

        refreshCategories() {
            const select = $("#categoryFilter");
            if (!select) return;
            const current = select.value;
            select.innerHTML = '<option value="">All categories</option>'
                + this.categories
                    .map((category) => `<option value="${escapeHtml(category.name)}">${escapeHtml(category.name)}</option>`)
                    .join("");
            if (current) {
                select.value = [...select.options].some((o) => o.value === current) ? current : "";
            }
        },

        applyFilter() {
            const query = $("#cropSearch") ? $("#cropSearch").value.trim().toLowerCase() : "";
            const category = $("#categoryFilter") ? $("#categoryFilter").value : "";

            const filtered = this.listings.filter((listing) => {
                const matchesCategory = !category || listing.category === category;
                const matchesQuery = !query
                    || (listing.cropName && listing.cropName.toLowerCase().includes(query));
                return matchesCategory && matchesQuery;
            });

            this.renderGrid(filtered);
        },

        renderGrid(listings) {
            const grid = $("#cropGrid");
            if (!grid) return;

            if (!listings.length) {
                grid.innerHTML = '<div class="empty-state">No produce listings match your filters.</div>';
                return;
            }

            grid.innerHTML = listings.map((listing) => this.cardMarkup(listing)).join("");
        },

        cardMarkup(listing) {
            const price = Number(listing.pricePerUnit || 0).toLocaleString("en-IN", {
                minimumFractionDigits: 0,
                maximumFractionDigits: 2,
            });
            const harvest = listing.harvestDate ? escapeHtml(listing.harvestDate) : "N/A";
            const category = escapeHtml(listing.category || "Produce");
            const location = escapeHtml(listing.location || "Location unknown");
            const cropName = escapeHtml(listing.cropName || "Unnamed produce");
            const quantity = Number(listing.availableQuantity || 0).toLocaleString("en-IN");
            const unit = escapeHtml(listing.unit || "kg");

            return `
                <div class="card crop-card">
                    <div class="flex items-start justify-between gap-2">
                        <h3 class="crop-name">${cropName}</h3>
                        <span class="badge badge-success">${category}</span>
                    </div>
                    <p class="text-muted my-0">📍 ${location}</p>
                    <div>
                        <span class="crop-price">৳${price}</span>
                        <span class="text-muted"> / ${unit}</span>
                    </div>
                    <div class="crop-meta">
                        <span class="chip">Qty ${quantity} ${unit}</span>
                        <span class="chip">Harvest ${harvest}</span>
                    </div>
                    <button type="button" class="btn btn-primary btn-sm crop-offer" data-auth-open>
                        Make an Offer
                    </button>
                </div>
            `;
        },
    };

    const Auth = {
        modal: null,

        init() {
            this.modal = $("#authModal");
            if (!this.modal) return;

            $$("[data-auth-close]").forEach((button) => {
                button.addEventListener("click", () => this.close());
            });

            $$("[data-auth-tab]").forEach((tab) => {
                tab.addEventListener("click", () => this.setTab(tab.dataset.authTab));
            });

            $$("input[name='registerRole']", $("#registerForm")).forEach((input) => {
                input.addEventListener("change", () => this.updateRoleSelection());
            });

            document.addEventListener("click", (event) => {
                const trigger = event.target.closest("[data-auth-open], [data-auth-open-register]");
                if (trigger) {
                    this.open(trigger.hasAttribute("data-auth-open-register") ? "register" : "login");
                }

                if (this.modal && event.target === this.modal) {
                    this.close();
                }
            });

            document.addEventListener("keydown", (event) => {
                if (event.key === "Escape" && this.isOpen()) this.close();
            });

            $("#loginForm").addEventListener("submit", (event) => this.handleLogin(event));
            $("#registerForm").addEventListener("submit", (event) => this.handleRegister(event));
        },

        isOpen() {
            return this.modal && this.modal.classList.contains("open");
        },

        open(tab = "login") {
            this.modal.classList.add("open");
            this.modal.setAttribute("aria-hidden", "false");
            this.setTab(tab);
            document.body.style.overflow = "hidden";
        },

        close() {
            this.modal.classList.remove("open");
            this.modal.setAttribute("aria-hidden", "true");
            document.body.style.overflow = "";
        },

        setTab(tab) {
            const target = tab === "register" ? "register" : "login";
            $$(".tab", this.modal).forEach((node) => {
                const active = node.dataset.authTab === target;
                node.classList.toggle("active", active);
                node.setAttribute("aria-selected", String(active));
            });
            $("#panel-login", this.modal).classList.toggle("active", target === "login");
            $("#panel-register", this.modal).classList.toggle("active", target === "register");
        },

        updateRoleSelection() {
            $$(".role-option", $("#registerForm")).forEach((label) => {
                label.classList.toggle("active", label.querySelector("input").checked);
            });
        },

        activeRole() {
            const checked = $("input[name='registerRole']:checked", $("#registerForm"));
            return checked ? checked.value : "FARMER";
        },

        async handleLogin(event) {
            event.preventDefault();
            const form = $("#loginForm");
            if (!form.checkValidity()) {
                form.reportValidity();
                return;
            }
            const payload = {
                email: $("#loginEmail").value.trim(),
                password: $("#loginPassword").value,
            };
            await this.submit(form, () => Api.post("/auth/login", payload), "Welcome back!");
        },

        async handleRegister(event) {
            event.preventDefault();
            const form = $("#registerForm");
            if (!form.checkValidity()) {
                form.reportValidity();
                return;
            }
            const payload = {
                name: $("#registerName").value.trim(),
                email: $("#registerEmail").value.trim(),
                password: $("#registerPassword").value,
                role: this.activeRole(),
                phone: $("#registerPhone").value.trim() || null,
                location: $("#registerLocation").value.trim() || null,
            };
            await this.submit(form, () => Api.post("/auth/register", payload), "Account created!");
        },

        async submit(form, request, successMessage) {
            const button = form.querySelector("button[type='submit']");
            const original = button.textContent;
            button.disabled = true;
            button.textContent = "Please wait...";
            Loader.show("Working...");

            try {
                const response = await request();
                if (response && response.success) {
                    window.Api.setToken(response.data.token);
                    window.Api.setUser(response.data);
                    Toast.success(successMessage);
                    setTimeout(() => {
                        window.location.href = "/dashboard";
                    }, 400);
                    return;
                }
                Toast.error(response && response.message ? response.message : "Something went wrong");
            } catch (error) {
                Toast.error(error && error.message ? error.message : "Something went wrong");
            } finally {
                button.disabled = false;
                button.textContent = original;
                Loader.hide();
            }
        },
    };

    const ThemeControls = {
        init() {
            $$("[data-theme-toggle]").forEach((button) => {
                button.addEventListener("click", () => {
                    Theme.toggle();
                    this.renderIcons();
                });
            });
            document.addEventListener("themechange", () => this.renderIcons());
            this.renderIcons();
        },

        renderIcons() {
            const dark = Theme.isDark();
            $$("[data-theme-icon]").forEach((icon) => {
                const isMoon = icon.dataset.themeIcon === "moon";
                icon.classList.toggle("hidden", dark ? isMoon : !isMoon);
            });
        },
    };

    function escapeHtml(value) {
        return String(value)
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    }

    document.addEventListener("DOMContentLoaded", () => {
        if (window.Theme) ThemeControls.init();

        Explorer.init();

        const searchInput = $("#cropSearch");
        const categoryFilter = $("#categoryFilter");
        const refreshButton = $("[data-explore-refresh]");

        if (searchInput) {
            searchInput.addEventListener("input", () => Explorer.applyFilter());
        }
        if (categoryFilter) {
            categoryFilter.addEventListener("change", () => Explorer.applyFilter());
        }
        if (refreshButton) {
            refreshButton.addEventListener("click", () => Explorer.init(true));
        }

        $$("[data-explore]").forEach((button) => {
            button.addEventListener("click", () => {
                const target = $("#explore");
                if (target) target.scrollIntoView({ behavior: "smooth" });
            });
        });

        Auth.init();
    });
})();