package com.agrolink.app.repository;

import com.agrolink.app.model.Order;
import com.agrolink.app.model.OrderStatus;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface OrderRepository extends MongoRepository<Order, String> {

    List<Order> findByBuyerId(String buyerId);

    List<Order> findByFarmerId(String farmerId);

    List<Order> findByOrderStatus(OrderStatus orderStatus);

    List<Order> findByBuyerIdAndOrderStatus(String buyerId, OrderStatus orderStatus);

    List<Order> findByFarmerIdAndOrderStatus(String farmerId, OrderStatus orderStatus);

    Optional<Order> findByOfferId(String offerId);

    List<Order> findByCreatedAtAfterOrderByCreatedAtDesc(java.time.Instant since);

    long countByOrderStatus(OrderStatus orderStatus);

    List<Order> findTop10ByOrderByCreatedAtDesc();
}